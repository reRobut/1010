import { _decorator, Component, Node, Prefab, instantiate, Color, Sprite, Label, SpriteFrame, UITransform, color, Vec2, Vec3, EventTouch, Camera, Canvas } from 'cc';
const { ccclass, property } = _decorator;

// ─── 常量 ───────────────────────────────────────────────
const ROWS = 10;
const COLS = 10;
const CELL_SIZE = 58;
const CELL_GAP = 4;
const STEP = CELL_SIZE + CELL_GAP;

const PIECE_COLORS: Color[] = [
    color('#E84855'),
    color('#F4A259'),
    color('#3BB5C8'),
    color('#7C6FFF'),
];

const EMPTY_COLOR: Color = color('#1E1E35');

// ─── 形状库 ─────────────────────────────────────────────
interface ShapeDef {
    name: string;
    matrix: number[][];
    weight: number;
    canRotate: boolean;
    canMirror: boolean;
}

const SHAPE_LIBRARY: ShapeDef[] = [
    { name: "dot",    matrix: [[1]],                                                        weight: 10, canRotate: false, canMirror: false },
    { name: "22full", matrix: [[1,1],[1,1]],                                                weight: 60, canRotate: false, canMirror: false },
    { name: "5CROSS", matrix: [[0,0,1,0,0],[0,0,1,0,0],[1,1,0,1,1],[0,0,1,0,0],[0,0,1,0,0]], weight: 5,  canRotate: false, canMirror: false },
    { name: "kou",    matrix: [[1,1,1],[1,0,1],[1,1,1]],                                    weight: 25, canRotate: false, canMirror: false },
    { name: "23L",    matrix: [[1,0],[1,0],[1,1]],                                          weight: 50, canRotate: true,  canMirror: true  },
    { name: "longPu", matrix: [[0,1,0],[0,1,0],[1,1,1]],                                   weight: 25, canRotate: false, canMirror: false },
    { name: "six",    matrix: [[1,0],[1,1],[1,1]],                                          weight: 40, canRotate: true,  canMirror: true  },
    { name: "pu",     matrix: [[1,0],[1,1],[1,0]],                                          weight: 40, canRotate: true,  canMirror: true  },
    { name: "3dots",  matrix: [[1,0],[1,1]],                                                weight: 70, canRotate: true,  canMirror: true  },
    { name: "23Z",    matrix: [[0,1,1],[1,1,0]],                                            weight: 45, canRotate: true,  canMirror: true  },
    { name: "24Z",    matrix: [[0,1],[1,1],[1,0],[1,0]],                                    weight: 30, canRotate: true,  canMirror: true  },
    { name: "34Z",    matrix: [[1,1,0],[0,1,0],[0,1,0],[0,1,1]],                            weight: 10, canRotate: true,  canMirror: true  },
    { name: "line2",  matrix: [[1,1]],                                                      weight: 50, canRotate: true,  canMirror: false },
    { name: "line3",  matrix: [[1,1,1]],                                                    weight: 45, canRotate: true,  canMirror: false },
    { name: "line4",  matrix: [[1,1,1,1]],                                                  weight: 15, canRotate: true,  canMirror: false },
    { name: "line5",  matrix: [[1,1,1,1,1]],                                                weight: 10, canRotate: true,  canMirror: false },
    { name: "stair",  matrix: [[0,1,1],[1,1,0],[1,0,0]],                                   weight: 25, canRotate: true,  canMirror: true  },
];

// ─── 矩阵工具函数 ────────────────────────────────────────
function rotateMatrix(matrix: number[][]): number[][] {
    return matrix[0].map((_, index) => matrix.map(row => row[index]).reverse());
}

function mirrorMatrix(matrix: number[][]): number[][] {
    return matrix.map(row => [...row].reverse());
}

function weightedRandom(shapes: ShapeDef[]): ShapeDef {
    const total = shapes.reduce((s, x) => s + x.weight, 0);
    let r = Math.random() * total;
    for (const x of shapes) { r -= x.weight; if (r <= 0) return x; }
    return shapes[shapes.length - 1];
}

function generateColoredMatrix(): { matrix: number[][], name: string } {
    const def = weightedRandom(SHAPE_LIBRARY);
    let m = def.matrix.map(r => [...r]);
    if (def.canRotate) {
        const n = Math.floor(Math.random() * 4);
        for (let i = 0; i < n; i++) m = rotateMatrix(m);
    }
    if (def.canMirror && Math.random() < 0.5) m = mirrorMatrix(m);

    const rows = m.length;
    const cols = m[0].length;
    const colored: number[][] = Array.from({ length: rows }, () => Array(cols).fill(-1));

    for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
            if (m[r][c] !== 1) continue;
            const forbidden = new Set<number>();
            if (r > 0 && colored[r-1][c] >= 0) forbidden.add(colored[r-1][c]);
            if (c > 0 && colored[r][c-1] >= 0) forbidden.add(colored[r][c-1]);
            const available = [0, 1, 2, 3].filter(id => !forbidden.has(id));
            colored[r][c] = available[Math.floor(Math.random() * available.length)];
        }
    }

    return { matrix: colored, name: def.name };
}

// ─── 主组件 ──────────────────────────────────────────────
@ccclass('BoardManager')
export class BoardManager extends Component {

    @property(Prefab)
    cellPrefab: Prefab = null;

    @property(Node)
    piecesArea: Node = null;

    @property(Label)
    scoreLabel: Label = null;

    @property(Label)
    bestLabel: Label = null;

    @property(Node)
    gameOverPanel: Node = null;

    @property(Label)
    gameOverScoreLabel: Label = null;

    // ── 内部状态 ──
    private boardData: number[][] = [];
    private cellNodes: Node[][] = [];
    private pieces: ({ matrix: number[][], name: string } | null)[] = [null, null];
    private selectedSlot: number = -1;
    private score: number = 0;
    private best: number = 0;
    private slotNodes: Node[] = [];

    // ── 拖拽相关 ──
    /** 跟随鼠标的"幽灵"预览节点容器 */
    private dragGhostNode: Node = null;
    /** 当前预览落点（棋盘行列），-1 表示无效 */
    private previewRow: number = -1;
    private previewCol: number = -1;
    /** 棋盘左上角第一格的世界坐标（本地坐标系下） */
    private boardStartX: number = 0;
    private boardStartY: number = 0;

    onLoad() {
        this.initBoard();
        this.slotNodes = [
            this.piecesArea.getChildByName('Slot0'),
            this.piecesArea.getChildByName('Slot1'),
        ];
        this.dealPieces();
        this.updateScoreUI();
        if (this.gameOverPanel) this.gameOverPanel.active = false;

        // 计算棋盘起始坐标（与 initBoard 中一致）
        const boardWidth = COLS * STEP - CELL_GAP;
        const boardHeight = ROWS * STEP - CELL_GAP;
        this.boardStartX = -boardWidth / 2 + CELL_SIZE / 2;
        this.boardStartY = boardHeight / 2 - CELL_SIZE / 2;

        // 在棋盘节点上监听全局触摸移动与结束，用于拖拽
        this.node.on(Node.EventType.TOUCH_MOVE, this.onGlobalTouchMove, this);
        this.node.on(Node.EventType.TOUCH_END,  this.onGlobalTouchEnd,  this);
        this.node.on(Node.EventType.TOUCH_CANCEL, this.cancelDrag, this);
    }

    onDestroy() {
        this.node.off(Node.EventType.TOUCH_MOVE, this.onGlobalTouchMove, this);
        this.node.off(Node.EventType.TOUCH_END,  this.onGlobalTouchEnd,  this);
        this.node.off(Node.EventType.TOUCH_CANCEL, this.cancelDrag, this);
    }

    // ════════════════════════════════════════════════════
    //  棋盘初始化
    // ════════════════════════════════════════════════════
    private initBoard() {
        this.boardData = Array.from({ length: ROWS }, () => Array(COLS).fill(-1));
        this.cellNodes = Array.from({ length: ROWS }, () => Array(COLS).fill(null));

        const boardWidth = COLS * STEP - CELL_GAP;
        const boardHeight = ROWS * STEP - CELL_GAP;
        const startX = -boardWidth / 2 + CELL_SIZE / 2;
        const startY = boardHeight / 2 - CELL_SIZE / 2;

        for (let r = 0; r < ROWS; r++) {
            for (let c = 0; c < COLS; c++) {
                const cell = instantiate(this.cellPrefab);
                cell.setPosition(startX + c * STEP, startY - r * STEP, 0);

                const ui = cell.getComponent(UITransform);
                if (ui) { ui.width = CELL_SIZE; ui.height = CELL_SIZE; }

                this.node.addChild(cell);
                this.cellNodes[r][c] = cell;
                this.setCellColor(r, c, -1);

                // 棋盘格点击现在改为：如果正在拖拽则放置
                const row = r, col = c;
                cell.on(Node.EventType.TOUCH_END, () => this.onCellTap(row, col), this);
            }
        }
    }

    // ════════════════════════════════════════════════════
    //  颜色渲染
    // ════════════════════════════════════════════════════
    private setCellColor(r: number, c: number, colorId: number, alpha: number = 255) {
        const sprite = this.cellNodes[r][c].getComponent(Sprite);
        if (!sprite) return;
        if (colorId >= 0) {
            const base = PIECE_COLORS[colorId];
            sprite.color = new Color(base.r, base.g, base.b, alpha);
        } else {
            sprite.color = EMPTY_COLOR.clone();
        }
    }

    // ════════════════════════════════════════════════════
    //  候选方块生成与渲染
    // ════════════════════════════════════════════════════
    private dealPieces() {
        this.pieces = [generateColoredMatrix(), generateColoredMatrix()];
        this.selectedSlot = -1;
        this.renderSlots();
    }

    private renderSlots() {
        for (let i = 0; i < 2; i++) {
            const slot = this.slotNodes[i];
            if (!slot) continue;
            slot.removeAllChildren();

            const p = this.pieces[i];
            if (!p) { slot.active = false; continue; }
            slot.active = true;

            const MINI = 30;
            const GAP = 2;
            const miniStep = MINI + GAP;
            const rows = p.matrix.length;
            const cols = p.matrix[0].length;
            const ox = -(cols * miniStep - GAP) / 2 + MINI / 2;
            const oy = (rows * miniStep - GAP) / 2 - MINI / 2;

            p.matrix.forEach((row, dr) => {
                row.forEach((v, dc) => {
                    if (v < 0) return;
                    const mini = instantiate(this.cellPrefab);
                    mini.setPosition(ox + dc * miniStep, oy - dr * miniStep, 0);
                    const ui = mini.getComponent(UITransform);
                    if (ui) { ui.width = MINI; ui.height = MINI; }
                    const sp = mini.getComponent(Sprite);
                    if (sp) sp.color = PIECE_COLORS[v];
                    slot.addChild(mini);
                });
            });

            // 选中状态视觉反馈：缩放
            slot.setScale(this.selectedSlot === i ? new Vec3(1.15, 1.15, 1) : new Vec3(1, 1, 1));

            slot.off(Node.EventType.TOUCH_END);
            const idx = i;
            slot.on(Node.EventType.TOUCH_END, (e: EventTouch) => {
                e.propagationStopped = true; // 防止冒泡到棋盘
                this.onSlotTap(idx);
            }, this);
        }
    }

    // ════════════════════════════════════════════════════
    //  候选槽点击 → 开始拖拽
    // ════════════════════════════════════════════════════
    private onSlotTap(idx: number) {
        if (!this.pieces[idx]) return;

        if (this.selectedSlot === idx) {
            // 再次点击取消
            this.cancelDrag();
            return;
        }

        // 切换到新槽
        if (this.dragGhostNode) {
            this.dragGhostNode.destroy();
            this.dragGhostNode = null;
        }

        this.selectedSlot = idx;
        this.renderSlots();  // 更新选中高亮

        // 创建幽灵节点（随鼠标移动的半透明副本）
        this.createDragGhost(this.pieces[idx]);
    }

    // ════════════════════════════════════════════════════
    //  创建幽灵拖拽节点
    // ════════════════════════════════════════════════════
    private createDragGhost(p: { matrix: number[][], name: string }) {
        if (this.dragGhostNode) {
            this.dragGhostNode.destroy();
        }

        // 幽灵挂在 Canvas 根节点（或棋盘节点），保证层级最高
        this.dragGhostNode = new Node('DragGhost');
        // 挂到父节点确保在最上层
        const parent = this.node.parent ?? this.node;
        parent.addChild(this.dragGhostNode);

        const rows = p.matrix.length;
        const cols = p.matrix[0].length;
        // 幽灵用与棋盘相同的 CELL_SIZE，方便对齐
        const ox = -(cols * STEP - CELL_GAP) / 2 + CELL_SIZE / 2;
        const oy = (rows * STEP - CELL_GAP) / 2 - CELL_SIZE / 2;

        p.matrix.forEach((row, dr) => {
            row.forEach((v, dc) => {
                if (v < 0) return;
                const cell = instantiate(this.cellPrefab);
                cell.setPosition(ox + dc * STEP, oy - dr * STEP, 0);
                const ui = cell.getComponent(UITransform);
                if (ui) { ui.width = CELL_SIZE; ui.height = CELL_SIZE; }
                const sp = cell.getComponent(Sprite);
                if (sp) {
                    const base = PIECE_COLORS[v];
                    sp.color = new Color(base.r, base.g, base.b, 200); // 半透明
                }
                this.dragGhostNode.addChild(cell);
            });
        });
    }

    // ════════════════════════════════════════════════════
    //  全局触摸移动：更新幽灵位置 + 棋盘预测高亮
    // ════════════════════════════════════════════════════
  private onGlobalTouchMove(event: EventTouch) {
        if (this.selectedSlot < 0 || !this.dragGhostNode) return;

        // 1. 获取触摸点并转换为幽灵节点的本地坐标
        const touchPos = event.getUILocation(); 
        const parentUITransform = this.dragGhostNode.parent?.getComponent(UITransform);
        if (!parentUITransform) return;

        // 将屏幕坐标转换为幽灵节点父空间的本地坐标
        const ghostLocalPos = parentUITransform.convertToNodeSpaceAR(new Vec3(touchPos.x, touchPos.y, 0));
        this.dragGhostNode.setPosition(ghostLocalPos);

        // 2. 计算棋盘预测落点
        const boardUI = this.node.getComponent(UITransform);
        if (!boardUI) return;

        // 获取触摸点在棋盘节点下的本地位置
        const boardLocal = boardUI.convertToNodeSpaceAR(new Vec3(touchPos.x, touchPos.y, 0));

        // 【关键修复】：获取当前方块的定义，计算其矩阵中心偏移
        const p = this.pieces[this.selectedSlot];
        if (!p) return;
        
        const rows = p.matrix.length;
        const cols = p.matrix[0].length;

        /** 
         * 偏移补偿逻辑：
         * 因为 ghost 节点的中心点是 (0,0)，对应的是方块矩阵的几何中心。
         * 我们计算 row/col 时需要对齐到矩阵的 [0][0] 单元格。
         */
        const offsetX = (cols - 1) * STEP / 2;
        const offsetY = (rows - 1) * STEP / 2;

        const col = Math.round((boardLocal.x - this.boardStartX - offsetX) / STEP);
        const row = Math.round((this.boardStartY - boardLocal.y - offsetY) / STEP);

        this.updatePreview(row, col);
    }
    // ════════════════════════════════════════════════════
    //  全局触摸结束：放置或取消
    // ════════════════════════════════════════════════════
    private onGlobalTouchEnd(event: EventTouch) {
        if (this.selectedSlot < 0) return;

        if (this.previewRow >= 0 && this.previewCol >= 0) {
            const p = this.pieces[this.selectedSlot];
            if (p && this.canPlace(p.matrix, this.previewRow, this.previewCol)) {
                this.placePiece(this.previewRow, this.previewCol);
                return;
            }
        }
        // 落点无效不取消选中，让玩家继续拖
    }

    // ════════════════════════════════════════════════════
    //  棋盘格点击（兼容旧逻辑，作为备用放置方式）
    // ════════════════════════════════════════════════════
    private onCellTap(r: number, c: number) {
        if (this.selectedSlot < 0) return;
        const p = this.pieces[this.selectedSlot];
        if (!p) return;
        if (!this.canPlace(p.matrix, r, c)) return;
        this.placePiece(r, c);
    }

    // ════════════════════════════════════════════════════
    //  棋盘预测高亮更新
    // ════════════════════════════════════════════════════
    private updatePreview(row: number, col: number) {
        // 先清除旧预览
        this.clearPreview();

        if (this.selectedSlot < 0) return;
        const p = this.pieces[this.selectedSlot];
        if (!p) return;

        if (!this.canPlace(p.matrix, row, col)) {
            this.previewRow = -1;
            this.previewCol = -1;
            return;
        }

        this.previewRow = row;
        this.previewCol = col;

        // 渲染半透明预测
        p.matrix.forEach((rowArr, dr) => {
            rowArr.forEach((v, dc) => {
                if (v < 0) return;
                const nr = row + dr, nc = col + dc;
                this.setCellColor(nr, nc, v, 140); // 半透明
            });
        });
    }

    private clearPreview() {
        for (let r = 0; r < ROWS; r++)
            for (let c = 0; c < COLS; c++)
                if (this.boardData[r][c] < 0)
                    this.setCellColor(r, c, -1);
        this.previewRow = -1;
        this.previewCol = -1;
    }

    // ════════════════════════════════════════════════════
    //  取消拖拽
    // ════════════════════════════════════════════════════
    private cancelDrag() {
        this.selectedSlot = -1;
        this.clearPreview();
        if (this.dragGhostNode) {
            this.dragGhostNode.destroy();
            this.dragGhostNode = null;
        }
        this.renderSlots();
    }

    // ════════════════════════════════════════════════════
    //  放置方块（提取公共逻辑）
    // ════════════════════════════════════════════════════
    private placePiece(r: number, c: number) {
        const p = this.pieces[this.selectedSlot];
        if (!p) return;

        // 清除幽灵和预览
        this.clearPreview();
        if (this.dragGhostNode) {
            this.dragGhostNode.destroy();
            this.dragGhostNode = null;
        }

        let placed = 0;
        p.matrix.forEach((row, dr) => row.forEach((v, dc) => {
            if (v < 0) return;
            this.boardData[r + dr][c + dc] = v;
            this.setCellColor(r + dr, c + dc, v);
            placed++;
        }));
        this.score += placed;

        this.pieces[this.selectedSlot] = null;
        this.selectedSlot = -1;

        this.checkEliminate();

        if (this.pieces.every(p => p === null)) this.dealPieces();
        else this.renderSlots();

        this.updateScoreUI();

        if (!this.canAnyPlace()) this.showGameOver();
    }

    // ════════════════════════════════════════════════════
    //  放置合法性检查
    // ════════════════════════════════════════════════════
    private canPlace(matrix: number[][], tr: number, tc: number): boolean {
        for (let dr = 0; dr < matrix.length; dr++) {
            for (let dc = 0; dc < matrix[0].length; dc++) {
                if (matrix[dr][dc] < 0) continue;
                const nr = tr + dr, nc = tc + dc;
                if (nr < 0 || nr >= ROWS || nc < 0 || nc >= COLS) return false;
                if (this.boardData[nr][nc] >= 0) return false;
            }
        }
        return true;
    }

    private canAnyPlace(): boolean {
        for (const p of this.pieces) {
            if (!p) continue;
            for (let r = 0; r < ROWS; r++)
                for (let c = 0; c < COLS; c++)
                    if (this.canPlace(p.matrix, r, c)) return true;
        }
        return false;
    }

    // ════════════════════════════════════════════════════
    //  消除逻辑
    // ════════════════════════════════════════════════════
    private checkEliminate() {
        const toElim = new Set<string>();

        for (let r = 0; r < ROWS; r++) {
            const groups = this.findGroups(r, 'row');
            groups.forEach(g => g.forEach(k => toElim.add(k)));
        }
        for (let c = 0; c < COLS; c++) {
            const groups = this.findGroups(c, 'col');
            groups.forEach(g => g.forEach(k => toElim.add(k)));
        }

        if (toElim.size === 0) return;

        this.score += toElim.size * 2;

        toElim.forEach(key => {
            const [r, c] = key.split(',').map(Number);
            this.boardData[r][c] = -1;
            this.setCellColor(r, c, -1);
        });
    }

    private findGroups(idx: number, dir: 'row' | 'col'): string[][] {
        const result: string[][] = [];
        let seq: { r: number, c: number, v: number }[] = [];

        const len = dir === 'row' ? COLS : ROWS;
        for (let i = 0; i < len; i++) {
            const r = dir === 'row' ? idx : i;
            const c = dir === 'row' ? i : idx;
            const v = this.boardData[r][c];
            if (v >= 0) {
                if (seq.length > 0 && seq[seq.length - 1].v === v) {
                    seq.push({ r, c, v });
                } else {
                    seq = [{ r, c, v }];
                }
                if (seq.length >= 3) result.push(seq.map(x => `${x.r},${x.c}`));
            } else {
                seq = [];
            }
        }
        return result;
    }

    // ════════════════════════════════════════════════════
    //  UI 更新
    // ════════════════════════════════════════════════════
    private updateScoreUI() {
        if (this.scoreLabel) this.scoreLabel.string = String(this.score);
        if (this.score > this.best) {
            this.best = this.score;
            if (this.bestLabel) this.bestLabel.string = String(this.best);
        }
    }

    private showGameOver() {
        if (this.gameOverPanel) {
            this.gameOverPanel.active = true;
            if (this.gameOverScoreLabel)
                this.gameOverScoreLabel.string = `得分：${this.score}`;
        }
    }

    // ════════════════════════════════════════════════════
    //  重启按钮回调
    // ════════════════════════════════════════════════════
    public onRestartBtn() {
        this.cancelDrag();
        if (this.gameOverPanel) this.gameOverPanel.active = false;
        for (let r = 0; r < ROWS; r++)
            for (let c = 0; c < COLS; c++) {
                this.boardData[r][c] = -1;
                this.setCellColor(r, c, -1);
            }
        this.score = 0;
        this.updateScoreUI();
        this.dealPieces();
    }
}