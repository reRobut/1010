System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, Node, Prefab, instantiate, Color, Sprite, Label, UITransform, color, Vec3, input, Input, view, AudioClip, AudioSource, _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _dec9, _dec10, _dec11, _dec12, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _descriptor8, _descriptor9, _descriptor10, _descriptor11, _crd, ccclass, property, ROWS, COLS, CELL_SIZE, CELL_GAP, STEP, SKINS, currentSkinIndex, DIFFICULTY_WEIGHT, SHAPE_LIBRARY, BoardManager;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function getPieceColors() {
    return SKINS[currentSkinIndex].pieceColors;
  }

  function getEmptyColor() {
    return SKINS[currentSkinIndex].emptyColor;
  } // ─── 形状库 ─────────────────────────────────────────────


  // ─── 矩阵工具函数 ────────────────────────────────────────
  function rotateMatrix(matrix) {
    return matrix[0].map((_, index) => matrix.map(row => row[index]).reverse());
  }

  function mirrorMatrix(matrix) {
    return matrix.map(row => [...row].reverse());
  }

  function weightedRandom(shapes) {
    const total = shapes.reduce((sum, shape) => {
      return sum + DIFFICULTY_WEIGHT[shape.difficulty];
    }, 0);
    let r = Math.random() * total;

    for (const shape of shapes) {
      r -= DIFFICULTY_WEIGHT[shape.difficulty];
      if (r <= 0) return shape;
    }

    return shapes[shapes.length - 1];
  }

  function generateColoredMatrix() {
    const def = weightedRandom(SHAPE_LIBRARY);
    let m = def.matrix.map(r => [...r]);

    if (def.canRotate) {
      const n = Math.floor(Math.random() * 4);

      for (let i = 0; i < n; i++) m = rotateMatrix(m);
    }

    if (def.canMirror && Math.random() < 0.5) {
      m = mirrorMatrix(m);
    }

    const rows = m.length;
    const cols = m[0].length;
    const colored = Array.from({
      length: rows
    }, () => Array(cols).fill(-1));

    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        if (m[r][c] !== 1) continue;
        const forbidden = new Set();
        if (r > 0 && colored[r - 1][c] >= 0) forbidden.add(colored[r - 1][c]);
        if (c > 0 && colored[r][c - 1] >= 0) forbidden.add(colored[r][c - 1]);
        const available = [0, 1, 2, 3].filter(id => !forbidden.has(id));
        colored[r][c] = available[Math.floor(Math.random() * available.length)];
      }
    }

    return {
      matrix: colored,
      name: def.name
    };
  } // ─── 主组件 ──────────────────────────────────────────────


  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      Prefab = _cc.Prefab;
      instantiate = _cc.instantiate;
      Color = _cc.Color;
      Sprite = _cc.Sprite;
      Label = _cc.Label;
      UITransform = _cc.UITransform;
      color = _cc.color;
      Vec3 = _cc.Vec3;
      input = _cc.input;
      Input = _cc.Input;
      view = _cc.view;
      AudioClip = _cc.AudioClip;
      AudioSource = _cc.AudioSource;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "3de56AH/otI1pOKN0X894cC", "BoardManager", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node', 'Prefab', 'instantiate', 'Color', 'Sprite', 'Label', 'UITransform', 'color', 'Vec3', 'EventTouch', 'input', 'Input', 'view']);

      __checkObsolete__(['AudioClip', 'AudioSource']);

      ({
        ccclass,
        property
      } = _decorator); // ─── 常量 ───────────────────────────────────────────────

      ROWS = 10;
      COLS = 10; // 改成 let，方便根据屏幕宽度动态计算

      CELL_SIZE = 72;
      CELL_GAP = 5;
      STEP = CELL_SIZE + CELL_GAP;
      SKINS = [{
        name: '法国',
        pieceColors: [color('#88d2ec'), color('#DA4167'), color('#aa8cc4'), color('#083d77')],
        emptyColor: color('#ffffff')
      }, {
        name: '德国',
        pieceColors: [color('#F77F00'), color('#FCBF49'), color('#D62828'), color('#003049')],
        emptyColor: color('#ffffff')
      }, {
        name: '赛博朋克',
        pieceColors: [color('#00F5D4'), color('#F15BB5'), color('#FEE440'), color('#9B5DE5')],
        emptyColor: color('#1E1E35')
      }, {
        name: '自然',
        pieceColors: [color('#7f5539'), color('#C2A67F'), color('#89965f'), color('#414833')],
        emptyColor: color('#ffffff')
      }];
      currentSkinIndex = 0;
      DIFFICULTY_WEIGHT = {
        easy: 60,
        middle: 15,
        hard: 10,
        hell: 5,
        heaven: 20
      };
      SHAPE_LIBRARY = [{
        name: "dot",
        matrix: [[1]],
        difficulty: 'heaven',
        canRotate: false,
        canMirror: false
      }, {
        name: "22full",
        matrix: [[1, 1], [1, 1]],
        difficulty: 'easy',
        canRotate: false,
        canMirror: false
      }, {
        name: "5CROSS",
        matrix: [[0, 0, 1, 0, 0], [0, 0, 1, 0, 0], [1, 1, 0, 1, 1], [0, 0, 1, 0, 0], [0, 0, 1, 0, 0]],
        difficulty: 'hell',
        canRotate: false,
        canMirror: false
      }, {
        name: "kou",
        matrix: [[1, 1, 1], [1, 0, 1], [1, 1, 1]],
        difficulty: 'hard',
        canRotate: false,
        canMirror: false
      }, {
        name: "23L",
        matrix: [[1, 0], [1, 0], [1, 1]],
        difficulty: 'hard',
        canRotate: true,
        canMirror: true
      }, {
        name: "longPu",
        matrix: [[0, 1, 0], [0, 1, 0], [1, 1, 1]],
        difficulty: 'hard',
        canRotate: false,
        canMirror: false
      }, {
        name: "six",
        matrix: [[1, 0], [1, 1], [1, 1]],
        difficulty: 'middle',
        canRotate: true,
        canMirror: true
      }, {
        name: "pu",
        matrix: [[1, 0], [1, 1], [1, 0]],
        difficulty: 'easy',
        canRotate: true,
        canMirror: true
      }, {
        name: "3dots",
        matrix: [[1, 0], [1, 1]],
        difficulty: 'easy',
        canRotate: true,
        canMirror: true
      }, {
        name: "23Z",
        matrix: [[0, 1, 1], [1, 1, 0]],
        difficulty: 'hard',
        canRotate: true,
        canMirror: true
      }, {
        name: "24Z",
        matrix: [[0, 1], [1, 1], [1, 0], [1, 0]],
        difficulty: 'hard',
        canRotate: true,
        canMirror: true
      }, {
        name: "34Z",
        matrix: [[1, 1, 0], [0, 1, 0], [0, 1, 0], [0, 1, 1]],
        difficulty: 'hell',
        canRotate: true,
        canMirror: true
      }, {
        name: "line2",
        matrix: [[1, 1]],
        difficulty: 'easy',
        canRotate: true,
        canMirror: false
      }, {
        name: "line3",
        matrix: [[1, 1, 1]],
        difficulty: 'middle',
        canRotate: true,
        canMirror: false
      }, {
        name: "line4",
        matrix: [[1, 1, 1, 1]],
        difficulty: 'hard',
        canRotate: true,
        canMirror: false
      }, {
        name: "line5",
        matrix: [[1, 1, 1, 1, 1]],
        difficulty: 'hell',
        canRotate: true,
        canMirror: false
      }, {
        name: "stair",
        matrix: [[0, 1, 1], [1, 1, 0], [1, 0, 0]],
        difficulty: 'hell',
        canRotate: true,
        canMirror: true
      }];

      _export("BoardManager", BoardManager = (_dec = ccclass('BoardManager'), _dec2 = property(Prefab), _dec3 = property(Node), _dec4 = property(Label), _dec5 = property(Label), _dec6 = property(Node), _dec7 = property(Label), _dec8 = property(AudioSource), _dec9 = property(AudioClip), _dec10 = property(AudioClip), _dec11 = property(AudioClip), _dec12 = property(AudioClip), _dec(_class = (_class2 = class BoardManager extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "cellPrefab", _descriptor, this);

          _initializerDefineProperty(this, "piecesArea", _descriptor2, this);

          _initializerDefineProperty(this, "scoreLabel", _descriptor3, this);

          _initializerDefineProperty(this, "bestLabel", _descriptor4, this);

          _initializerDefineProperty(this, "gameOverPanel", _descriptor5, this);

          _initializerDefineProperty(this, "gameOverScoreLabel", _descriptor6, this);

          _initializerDefineProperty(this, "audioSource", _descriptor7, this);

          _initializerDefineProperty(this, "placeSound", _descriptor8, this);

          _initializerDefineProperty(this, "eliminateSound", _descriptor9, this);

          _initializerDefineProperty(this, "deathSound", _descriptor10, this);

          _initializerDefineProperty(this, "restartSound", _descriptor11, this);

          this.boardData = [];
          this.cellNodes = [];
          this.pieces = [null, null];
          this.selectedSlot = -1;
          this.score = 0;
          this.best = 0;
          this.slotNodes = [];
          this.dragGhostNode = null;
          this.previewRow = -1;
          this.previewCol = -1;
          this.boardStartX = 0;
          this.boardStartY = 0;
        }

        onLoad() {
          this.adaptBoardSize();
          this.initBoard();
          this.slotNodes = [this.piecesArea.getChildByName('Slot0'), this.piecesArea.getChildByName('Slot1')];
          this.dealPieces();
          this.updateScoreUI();
          if (this.gameOverPanel) this.gameOverPanel.active = false;
          const boardWidth = COLS * STEP - CELL_GAP;
          const boardHeight = ROWS * STEP - CELL_GAP;
          this.boardStartX = -boardWidth / 2 + CELL_SIZE / 2;
          this.boardStartY = boardHeight / 2 - CELL_SIZE / 2;
          input.on(Input.EventType.TOUCH_MOVE, this.onGlobalTouchMove, this);
          input.on(Input.EventType.TOUCH_END, this.onGlobalTouchEnd, this);
          input.on(Input.EventType.TOUCH_CANCEL, this.cancelDrag, this);
        }

        onDestroy() {
          input.off(Input.EventType.TOUCH_MOVE, this.onGlobalTouchMove, this);
          input.off(Input.EventType.TOUCH_END, this.onGlobalTouchEnd, this);
          input.off(Input.EventType.TOUCH_CANCEL, this.cancelDrag, this);
        } // 自适应棋盘宽度


        adaptBoardSize() {
          const visibleSize = view.getVisibleSize(); // 左右边距，越小棋盘越大

          const horizontalPadding = 60;
          const targetBoardWidth = visibleSize.width - horizontalPadding;
          CELL_GAP = Math.max(3, Math.floor(targetBoardWidth * 0.006));
          CELL_SIZE = Math.floor((targetBoardWidth - CELL_GAP * (COLS - 1)) / COLS);
          STEP = CELL_SIZE + CELL_GAP;
        }

        refreshBoardColors() {
          for (let r = 0; r < ROWS; r++) {
            for (let c = 0; c < COLS; c++) {
              this.setCellColor(r, c, this.boardData[r][c]);
            }
          }
        }

        initBoard() {
          this.boardData = Array.from({
            length: ROWS
          }, () => Array(COLS).fill(-1));
          this.cellNodes = Array.from({
            length: ROWS
          }, () => Array(COLS).fill(null));
          const boardWidth = COLS * STEP - CELL_GAP;
          const boardHeight = ROWS * STEP - CELL_GAP;
          const startX = -boardWidth / 2 + CELL_SIZE / 2;
          const startY = boardHeight / 2 - CELL_SIZE / 2;

          for (let r = 0; r < ROWS; r++) {
            for (let c = 0; c < COLS; c++) {
              const cell = instantiate(this.cellPrefab);
              cell.setPosition(startX + c * STEP, startY - r * STEP, 0);
              const ui = cell.getComponent(UITransform);

              if (ui) {
                ui.width = CELL_SIZE;
                ui.height = CELL_SIZE;
              }

              this.node.addChild(cell);
              this.cellNodes[r][c] = cell;
              this.setCellColor(r, c, -1);
              const row = r;
              const col = c;
              cell.on(Node.EventType.TOUCH_END, () => this.onCellTap(row, col), this);
            }
          }
        }

        setCellColor(r, c, colorId, alpha = 255) {
          if (r < 0 || r >= ROWS || c < 0 || c >= COLS) return;
          if (!this.cellNodes[r] || !this.cellNodes[r][c]) return;
          const sprite = this.cellNodes[r][c].getComponent(Sprite);
          if (!sprite) return;

          if (colorId >= 0) {
            const colors = getPieceColors();
            const base = colors[colorId];

            if (!base) {
              sprite.color = getEmptyColor().clone();
              return;
            }

            sprite.color = new Color(base.r, base.g, base.b, alpha);
          } else {
            sprite.color = getEmptyColor().clone();
          }
        }

        dealPieces() {
          this.pieces = [generateColoredMatrix(), generateColoredMatrix()];
          this.selectedSlot = -1;
          this.renderSlots();
        }

        renderSlots() {
          for (let i = 0; i < 2; i++) {
            const slot = this.slotNodes[i];
            if (!slot) continue;
            slot.removeAllChildren();
            const p = this.pieces[i];

            if (!p) {
              slot.active = false;
              continue;
            }

            slot.active = true;
            const slotUI = slot.getComponent(UITransform);

            if (slotUI) {
              slotUI.width = Math.max(260, CELL_SIZE * 4);
              slotUI.height = Math.max(260, CELL_SIZE * 4);
            } // 候选区也根据棋盘大小自动变化


            const MINI = Math.floor(CELL_SIZE * 0.72);
            const GAP = Math.max(2, Math.floor(CELL_GAP * 0.8));
            const miniStep = MINI + GAP;
            const rows = p.matrix.length;
            const cols = p.matrix[0].length;
            const ox = -(cols * miniStep - GAP) / 2 + MINI / 2;
            const oy = (rows * miniStep - GAP) / 2 - MINI / 2;
            p.matrix.forEach((row, dr) => {
              row.forEach((v, dc) => {
                if (v < 0) return;
                const mini = instantiate(this.cellPrefab);
                mini.setPosition(ox + dc * miniStep, oy - dr * miniStep, 0);
                const ui = mini.getComponent(UITransform);

                if (ui) {
                  ui.width = MINI;
                  ui.height = MINI;
                }

                const sp = mini.getComponent(Sprite);
                if (sp) sp.color = getPieceColors()[v];
                slot.addChild(mini);
              });
            });
            slot.setScale(new Vec3(1, 1, 1));
            slot.off(Node.EventType.TOUCH_START);
            slot.off(Node.EventType.TOUCH_MOVE);
            slot.off(Node.EventType.TOUCH_END);
            slot.off(Node.EventType.TOUCH_CANCEL);
            const idx = i;
            slot.on(Node.EventType.TOUCH_START, e => {
              this.beginDragFromSlot(idx, e);
            }, this);
          }
        }

        beginDragFromSlot(idx, event) {
          const p = this.pieces[idx];
          if (!p) return;
          event.propagationStopped = true;
          this.clearPreview();

          if (this.dragGhostNode) {
            this.dragGhostNode.destroy();
            this.dragGhostNode = null;
          }

          this.selectedSlot = idx;
          this.createDragGhost(p);

          if (this.slotNodes[idx]) {
            this.slotNodes[idx].active = false;
          }

          this.updateDragByTouch(event);
        }

        createDragGhost(p) {
          var _this$node$parent;

          if (this.dragGhostNode) {
            this.dragGhostNode.destroy();
          }

          this.dragGhostNode = new Node('DragGhost');
          const parent = (_this$node$parent = this.node.parent) != null ? _this$node$parent : this.node;
          parent.addChild(this.dragGhostNode);
          this.dragGhostNode.setSiblingIndex(parent.children.length - 1);
          const rows = p.matrix.length;
          const cols = p.matrix[0].length;
          const ox = -(cols * STEP - CELL_GAP) / 2 + CELL_SIZE / 2;
          const oy = (rows * STEP - CELL_GAP) / 2 - CELL_SIZE / 2;
          p.matrix.forEach((row, dr) => {
            row.forEach((v, dc) => {
              if (v < 0) return;
              const cell = instantiate(this.cellPrefab);
              cell.setPosition(ox + dc * STEP, oy - dr * STEP, 0);
              const ui = cell.getComponent(UITransform);

              if (ui) {
                ui.width = CELL_SIZE;
                ui.height = CELL_SIZE;
              }

              const sp = cell.getComponent(Sprite);

              if (sp) {
                const base = getPieceColors()[v];
                sp.color = new Color(base.r, base.g, base.b, 200);
              }

              this.dragGhostNode.addChild(cell);
            });
          });
        }

        onGlobalTouchMove(event) {
          this.updateDragByTouch(event);
        }

        updateDragByTouch(event) {
          var _this$dragGhostNode$p;

          if (this.selectedSlot < 0 || !this.dragGhostNode) return;
          const touchPos = event.getUILocation();
          const parentUITransform = (_this$dragGhostNode$p = this.dragGhostNode.parent) == null ? void 0 : _this$dragGhostNode$p.getComponent(UITransform);
          if (!parentUITransform) return;
          const ghostLocalPos = parentUITransform.convertToNodeSpaceAR(new Vec3(touchPos.x, touchPos.y, 0));
          this.dragGhostNode.setPosition(ghostLocalPos);
          const boardUI = this.node.getComponent(UITransform);
          if (!boardUI) return;
          const boardLocal = boardUI.convertToNodeSpaceAR(new Vec3(touchPos.x, touchPos.y, 0));
          const p = this.pieces[this.selectedSlot];
          if (!p) return;
          const rows = p.matrix.length;
          const cols = p.matrix[0].length;
          const offsetX = (cols - 1) * STEP / 2;
          const offsetY = (rows - 1) * STEP / 2;
          const col = Math.round((boardLocal.x - this.boardStartX - offsetX) / STEP);
          const row = Math.round((this.boardStartY - boardLocal.y - offsetY) / STEP);
          this.updatePreview(row, col);
        }

        onGlobalTouchEnd(event) {
          if (this.selectedSlot < 0) return;
          this.updateDragByTouch(event);

          if (this.previewRow >= 0 && this.previewCol >= 0) {
            const p = this.pieces[this.selectedSlot];

            if (p && this.canPlace(p.matrix, this.previewRow, this.previewCol)) {
              this.placePiece(this.previewRow, this.previewCol);
              return;
            }
          }

          this.cancelDrag();
        }

        onCellTap(r, c) {
          if (this.selectedSlot < 0) return;
          const p = this.pieces[this.selectedSlot];
          if (!p) return;
          if (!this.canPlace(p.matrix, r, c)) return;
          this.placePiece(r, c);
        }

        updatePreview(row, col) {
          this.clearPreview();
          if (this.selectedSlot < 0) return;
          const p = this.pieces[this.selectedSlot];
          if (!p) return;

          if (!this.canPlace(p.matrix, row, col)) {
            this.previewRow = -1;
            this.previewCol = -1;
            return;
          }

          this.previewRow = row;
          this.previewCol = col;
          p.matrix.forEach((rowArr, dr) => {
            rowArr.forEach((v, dc) => {
              if (v < 0) return;
              const nr = row + dr;
              const nc = col + dc;
              this.setCellColor(nr, nc, v, 140);
            });
          });
        }

        clearPreview() {
          for (let r = 0; r < ROWS; r++) {
            for (let c = 0; c < COLS; c++) {
              if (this.boardData[r][c] < 0) {
                this.setCellColor(r, c, -1);
              }
            }
          }

          this.previewRow = -1;
          this.previewCol = -1;
        }

        cancelDrag() {
          this.selectedSlot = -1;
          this.clearPreview();

          if (this.dragGhostNode) {
            this.dragGhostNode.destroy();
            this.dragGhostNode = null;
          }

          this.renderSlots();
        }

        placePiece(r, c) {
          const p = this.pieces[this.selectedSlot];
          if (!p) return;
          this.clearPreview();

          if (this.dragGhostNode) {
            this.dragGhostNode.destroy();
            this.dragGhostNode = null;
          }

          let placed = 0;
          p.matrix.forEach((row, dr) => {
            row.forEach((v, dc) => {
              if (v < 0) return;
              this.boardData[r + dr][c + dc] = v;
              this.setCellColor(r + dr, c + dc, v);
              placed++;
            });
          });
          this.score += placed;

          if (this.audioSource && this.placeSound) {
            this.audioSource.playOneShot(this.placeSound);
          }

          this.pieces[this.selectedSlot] = null;
          this.selectedSlot = -1;
          this.checkEliminate();

          if (this.pieces.every(p => p === null)) {
            this.dealPieces();
          } else {
            this.renderSlots();
          }

          this.updateScoreUI();

          if (!this.canAnyPlace()) {
            this.showGameOver();
          }
        }

        canPlace(matrix, tr, tc) {
          for (let dr = 0; dr < matrix.length; dr++) {
            for (let dc = 0; dc < matrix[0].length; dc++) {
              if (matrix[dr][dc] < 0) continue;
              const nr = tr + dr;
              const nc = tc + dc;
              if (nr < 0 || nr >= ROWS || nc < 0 || nc >= COLS) return false;
              if (this.boardData[nr][nc] >= 0) return false;
            }
          }

          return true;
        }

        canAnyPlace() {
          for (const p of this.pieces) {
            if (!p) continue;

            for (let r = 0; r < ROWS; r++) {
              for (let c = 0; c < COLS; c++) {
                if (this.canPlace(p.matrix, r, c)) return true;
              }
            }
          }

          return false;
        }

        checkEliminate() {
          const groups = this.findConnectedColorGroups(3);
          if (groups.length === 0) return;

          if (this.audioSource && this.eliminateSound) {
            this.audioSource.playOneShot(this.eliminateSound);
          }

          const toElim = new Set();
          groups.forEach(group => {
            group.forEach(pos => toElim.add(`${pos.r},${pos.c}`));
          });
          this.score += toElim.size * 2;
          toElim.forEach(key => {
            const [r, c] = key.split(',').map(Number);
            this.boardData[r][c] = -1;
            this.setCellColor(r, c, -1);
          });
        }

        findConnectedColorGroups(minCount) {
          const result = [];
          const visited = Array.from({
            length: ROWS
          }, () => Array(COLS).fill(false));
          const dirs = [{
            r: -1,
            c: 0
          }, {
            r: 1,
            c: 0
          }, {
            r: 0,
            c: -1
          }, {
            r: 0,
            c: 1
          }];

          for (let sr = 0; sr < ROWS; sr++) {
            for (let sc = 0; sc < COLS; sc++) {
              const colorId = this.boardData[sr][sc];
              if (colorId < 0 || visited[sr][sc]) continue;
              const group = [];
              const queue = [{
                r: sr,
                c: sc
              }];
              visited[sr][sc] = true;

              while (queue.length > 0) {
                const cur = queue.shift();
                if (!cur) continue;
                group.push(cur);

                for (const d of dirs) {
                  const nr = cur.r + d.r;
                  const nc = cur.c + d.c;
                  if (nr < 0 || nr >= ROWS || nc < 0 || nc >= COLS) continue;
                  if (visited[nr][nc]) continue;
                  if (this.boardData[nr][nc] !== colorId) continue;
                  visited[nr][nc] = true;
                  queue.push({
                    r: nr,
                    c: nc
                  });
                }
              }

              if (group.length >= minCount) {
                result.push(group);
              }
            }
          }

          return result;
        }

        updateScoreUI() {
          if (this.scoreLabel) {
            this.scoreLabel.string = String(this.score);
          }

          if (this.score > this.best) {
            this.best = this.score;

            if (this.bestLabel) {
              this.bestLabel.string = String(this.best);
            }
          }
        }

        showGameOver() {
          if (this.audioSource && this.deathSound) {
            this.audioSource.playOneShot(this.deathSound);
          }

          if (this.gameOverPanel) {
            this.gameOverPanel.active = true;

            if (this.gameOverScoreLabel) {
              this.gameOverScoreLabel.string = `得分：${this.score}`;
            }
          }
        }

        onSkinBtn() {
          currentSkinIndex++;

          if (currentSkinIndex >= SKINS.length) {
            currentSkinIndex = 0;
          }

          this.refreshBoardColors();
          this.renderSlots();
        }

        onRestartBtn() {
          if (this.audioSource && this.restartSound) {
            this.audioSource.playOneShot(this.restartSound);
          }

          this.cancelDrag();

          if (this.gameOverPanel) {
            this.gameOverPanel.active = false;
          }

          for (let r = 0; r < ROWS; r++) {
            for (let c = 0; c < COLS; c++) {
              this.boardData[r][c] = -1;
              this.setCellColor(r, c, -1);
            }
          }

          this.score = 0;
          this.updateScoreUI();
          this.dealPieces();
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "cellPrefab", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "piecesArea", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "scoreLabel", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "bestLabel", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "gameOverPanel", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "gameOverScoreLabel", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "audioSource", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor8 = _applyDecoratedDescriptor(_class2.prototype, "placeSound", [_dec9], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor9 = _applyDecoratedDescriptor(_class2.prototype, "eliminateSound", [_dec10], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor10 = _applyDecoratedDescriptor(_class2.prototype, "deathSound", [_dec11], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor11 = _applyDecoratedDescriptor(_class2.prototype, "restartSound", [_dec12], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=e534354d4a29b0bb2da7672226359c0c4f1263f2.js.map