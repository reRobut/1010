System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, Node, Prefab, instantiate, Color, Sprite, Label, UITransform, color, Vec3, input, Input, AudioClip, AudioSource, _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _dec9, _dec10, _dec11, _dec12, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _descriptor8, _descriptor9, _descriptor10, _descriptor11, _crd, ccclass, property, ROWS, COLS, CELL_SIZE, CELL_GAP, STEP, PIECE_COLORS, EMPTY_COLOR, DIFFICULTY_WEIGHT, SHAPE_LIBRARY, BoardManager;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  // ─── 矩阵工具函数 ────────────────────────────────────────
  function rotateMatrix(matrix) {
    return matrix[0].map((_, index) => matrix.map(row => row[index]).reverse());
  }

  function mirrorMatrix(matrix) {
    return matrix.map(row => [...row].reverse());
  }

  function weightedRandom(shapes) {
    var total = shapes.reduce((sum, shape) => {
      return sum + DIFFICULTY_WEIGHT[shape.difficulty];
    }, 0);
    var r = Math.random() * total;

    for (var shape of shapes) {
      r -= DIFFICULTY_WEIGHT[shape.difficulty];

      if (r <= 0) {
        return shape;
      }
    }

    return shapes[shapes.length - 1];
  }

  function generateColoredMatrix() {
    var def = weightedRandom(SHAPE_LIBRARY);
    var m = def.matrix.map(r => [...r]);

    if (def.canRotate) {
      var n = Math.floor(Math.random() * 4);

      for (var i = 0; i < n; i++) m = rotateMatrix(m);
    }

    if (def.canMirror && Math.random() < 0.5) m = mirrorMatrix(m);
    var rows = m.length;
    var cols = m[0].length;
    var colored = Array.from({
      length: rows
    }, () => Array(cols).fill(-1));

    for (var r = 0; r < rows; r++) {
      var _loop = function _loop() {
        if (m[r][c] !== 1) return 1; // continue

        var forbidden = new Set();
        if (r > 0 && colored[r - 1][c] >= 0) forbidden.add(colored[r - 1][c]);
        if (c > 0 && colored[r][c - 1] >= 0) forbidden.add(colored[r][c - 1]);
        var available = [0, 1, 2, 3].filter(id => !forbidden.has(id));
        colored[r][c] = available[Math.floor(Math.random() * available.length)];
      };

      for (var c = 0; c < cols; c++) {
        if (_loop()) continue;
      }
    }

    return {
      matrix: colored,
      name: def.name
    };
  } // ─── 主组件 ──────────────────────────────────────────────


  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      Prefab = _cc.Prefab;
      instantiate = _cc.instantiate;
      Color = _cc.Color;
      Sprite = _cc.Sprite;
      Label = _cc.Label;
      UITransform = _cc.UITransform;
      color = _cc.color;
      Vec3 = _cc.Vec3;
      input = _cc.input;
      Input = _cc.Input;
      AudioClip = _cc.AudioClip;
      AudioSource = _cc.AudioSource;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "3de56AH/otI1pOKN0X894cC", "BoardManager", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node', 'Prefab', 'instantiate', 'Color', 'Sprite', 'Label', 'SpriteFrame', 'UITransform', 'color', 'Vec2', 'Vec3', 'EventTouch', 'input', 'Input']);

      __checkObsolete__(['AudioClip', 'AudioSource']);

      ({
        ccclass,
        property
      } = _decorator); // ─── 常量 ───────────────────────────────────────────────

      ROWS = 10;
      COLS = 10;
      CELL_SIZE = 58;
      CELL_GAP = 4;
      STEP = CELL_SIZE + CELL_GAP;
      PIECE_COLORS = [color('#88d2ec'), color('#DA4167'), color('#aa8cc4'), color('#083d77')];
      EMPTY_COLOR = color('#ffffff'); // ─── 形状库 ─────────────────────────────────────────────

      DIFFICULTY_WEIGHT = {
        easy: 60,
        middle: 15,
        hard: 15,
        hell: 10,
        heaven: 20
      };
      SHAPE_LIBRARY = [{
        name: "dot",
        matrix: [[1]],
        difficulty: 'heaven',
        canRotate: false,
        canMirror: false
      }, {
        name: "22full",
        matrix: [[1, 1], [1, 1]],
        difficulty: 'easy',
        canRotate: false,
        canMirror: false
      }, {
        name: "5CROSS",
        matrix: [[0, 0, 1, 0, 0], [0, 0, 1, 0, 0], [1, 1, 0, 1, 1], [0, 0, 1, 0, 0], [0, 0, 1, 0, 0]],
        difficulty: 'hell',
        canRotate: false,
        canMirror: false
      }, {
        name: "kou",
        matrix: [[1, 1, 1], [1, 0, 1], [1, 1, 1]],
        difficulty: 'hard',
        canRotate: false,
        canMirror: false
      }, {
        name: "23L",
        matrix: [[1, 0], [1, 0], [1, 1]],
        difficulty: 'hard',
        canRotate: true,
        canMirror: true
      }, {
        name: "longPu",
        matrix: [[0, 1, 0], [0, 1, 0], [1, 1, 1]],
        difficulty: 'hard',
        canRotate: false,
        canMirror: false
      }, {
        name: "six",
        matrix: [[1, 0], [1, 1], [1, 1]],
        difficulty: 'middle',
        canRotate: true,
        canMirror: true
      }, {
        name: "pu",
        matrix: [[1, 0], [1, 1], [1, 0]],
        difficulty: 'easy',
        canRotate: true,
        canMirror: true
      }, {
        name: "3dots",
        matrix: [[1, 0], [1, 1]],
        difficulty: 'easy',
        canRotate: true,
        canMirror: true
      }, {
        name: "23Z",
        matrix: [[0, 1, 1], [1, 1, 0]],
        difficulty: 'hard',
        canRotate: true,
        canMirror: true
      }, {
        name: "24Z",
        matrix: [[0, 1], [1, 1], [1, 0], [1, 0]],
        difficulty: 'hard',
        canRotate: true,
        canMirror: true
      }, {
        name: "34Z",
        matrix: [[1, 1, 0], [0, 1, 0], [0, 1, 0], [0, 1, 1]],
        difficulty: 'hell',
        canRotate: true,
        canMirror: true
      }, {
        name: "line2",
        matrix: [[1, 1]],
        difficulty: 'easy',
        canRotate: true,
        canMirror: false
      }, {
        name: "line3",
        matrix: [[1, 1, 1]],
        difficulty: 'middle',
        canRotate: true,
        canMirror: false
      }, {
        name: "line4",
        matrix: [[1, 1, 1, 1]],
        difficulty: 'hard',
        canRotate: true,
        canMirror: false
      }, {
        name: "line5",
        matrix: [[1, 1, 1, 1, 1]],
        difficulty: 'hell',
        canRotate: true,
        canMirror: false
      }, {
        name: "stair",
        matrix: [[0, 1, 1], [1, 1, 0], [1, 0, 0]],
        difficulty: 'hell',
        canRotate: true,
        canMirror: true
      }];

      _export("BoardManager", BoardManager = (_dec = ccclass('BoardManager'), _dec2 = property(Prefab), _dec3 = property(Node), _dec4 = property(Label), _dec5 = property(Label), _dec6 = property(Node), _dec7 = property(Label), _dec8 = property(AudioSource), _dec9 = property(AudioClip), _dec10 = property(AudioClip), _dec11 = property(AudioClip), _dec12 = property(AudioClip), _dec(_class = (_class2 = class BoardManager extends Component {
        constructor() {
          super(...arguments);

          _initializerDefineProperty(this, "cellPrefab", _descriptor, this);

          _initializerDefineProperty(this, "piecesArea", _descriptor2, this);

          _initializerDefineProperty(this, "scoreLabel", _descriptor3, this);

          _initializerDefineProperty(this, "bestLabel", _descriptor4, this);

          _initializerDefineProperty(this, "gameOverPanel", _descriptor5, this);

          _initializerDefineProperty(this, "gameOverScoreLabel", _descriptor6, this);

          _initializerDefineProperty(this, "audioSource", _descriptor7, this);

          _initializerDefineProperty(this, "placeSound", _descriptor8, this);

          _initializerDefineProperty(this, "eliminateSound", _descriptor9, this);

          _initializerDefineProperty(this, "deathSound", _descriptor10, this);

          _initializerDefineProperty(this, "restartSound", _descriptor11, this);

          // ── 内部状态 ──
          this.boardData = [];
          this.cellNodes = [];
          this.pieces = [null, null];
          this.selectedSlot = -1;
          this.score = 0;
          this.best = 0;
          this.slotNodes = [];
          // ── 拖拽相关 ──

          /** 跟随鼠标的"幽灵"预览节点容器 */
          this.dragGhostNode = null;

          /** 当前预览落点（棋盘行列），-1 表示无效 */
          this.previewRow = -1;
          this.previewCol = -1;

          /** 棋盘左上角第一格的世界坐标（本地坐标系下） */
          this.boardStartX = 0;
          this.boardStartY = 0;
        }

        onLoad() {
          this.initBoard();
          this.slotNodes = [this.piecesArea.getChildByName('Slot0'), this.piecesArea.getChildByName('Slot1')];
          this.dealPieces();
          this.updateScoreUI();
          if (this.gameOverPanel) this.gameOverPanel.active = false; // 计算棋盘起始坐标（与 initBoard 中一致）

          var boardWidth = COLS * STEP - CELL_GAP;
          var boardHeight = ROWS * STEP - CELL_GAP;
          this.boardStartX = -boardWidth / 2 + CELL_SIZE / 2;
          this.boardStartY = boardHeight / 2 - CELL_SIZE / 2; // 用 input 监听全局触摸。
          // 注意：拖拽从 Slot 开始后，手指通常会离开 Slot/Board 节点范围，
          // 只监听 this.node 或 slot 容易收不到 TOUCH_END，导致松手后无法真正放置。

          input.on(Input.EventType.TOUCH_MOVE, this.onGlobalTouchMove, this);
          input.on(Input.EventType.TOUCH_END, this.onGlobalTouchEnd, this);
          input.on(Input.EventType.TOUCH_CANCEL, this.cancelDrag, this);
        }

        onDestroy() {
          input.off(Input.EventType.TOUCH_MOVE, this.onGlobalTouchMove, this);
          input.off(Input.EventType.TOUCH_END, this.onGlobalTouchEnd, this);
          input.off(Input.EventType.TOUCH_CANCEL, this.cancelDrag, this);
        } // ════════════════════════════════════════════════════
        //  棋盘初始化
        // ════════════════════════════════════════════════════


        initBoard() {
          var _this = this;

          this.boardData = Array.from({
            length: ROWS
          }, () => Array(COLS).fill(-1));
          this.cellNodes = Array.from({
            length: ROWS
          }, () => Array(COLS).fill(null));
          var boardWidth = COLS * STEP - CELL_GAP;
          var boardHeight = ROWS * STEP - CELL_GAP;
          var startX = -boardWidth / 2 + CELL_SIZE / 2;
          var startY = boardHeight / 2 - CELL_SIZE / 2;

          for (var r = 0; r < ROWS; r++) {
            var _loop2 = function _loop2() {
              var cell = instantiate(_this.cellPrefab);
              cell.setPosition(startX + c * STEP, startY - r * STEP, 0);
              var ui = cell.getComponent(UITransform);

              if (ui) {
                ui.width = CELL_SIZE;
                ui.height = CELL_SIZE;
              }

              _this.node.addChild(cell);

              _this.cellNodes[r][c] = cell;

              _this.setCellColor(r, c, -1); // 棋盘格点击现在改为：如果正在拖拽则放置


              var row = r,
                  col = c;
              cell.on(Node.EventType.TOUCH_END, () => _this.onCellTap(row, col), _this);
            };

            for (var c = 0; c < COLS; c++) {
              _loop2();
            }
          }
        } // ════════════════════════════════════════════════════
        //  颜色渲染
        // ════════════════════════════════════════════════════


        setCellColor(r, c, colorId, alpha) {
          if (alpha === void 0) {
            alpha = 255;
          }

          var sprite = this.cellNodes[r][c].getComponent(Sprite);
          if (!sprite) return;

          if (colorId >= 0) {
            var base = PIECE_COLORS[colorId];
            sprite.color = new Color(base.r, base.g, base.b, alpha);
          } else {
            sprite.color = EMPTY_COLOR.clone();
          }
        } // ════════════════════════════════════════════════════
        //  候选方块生成与渲染
        // ════════════════════════════════════════════════════


        dealPieces() {
          this.pieces = [generateColoredMatrix(), generateColoredMatrix()];
          this.selectedSlot = -1;
          this.renderSlots();
        }

        renderSlots() {
          var _this2 = this;

          var _loop3 = function _loop3() {
            var slot = _this2.slotNodes[i];
            if (!slot) return 0; // continue

            slot.removeAllChildren();
            var p = _this2.pieces[i];

            if (!p) {
              slot.active = false;
              return 0; // continue
            }

            slot.active = true;
            var MINI = 40;
            var GAP = 2;
            var miniStep = MINI + GAP;
            var rows = p.matrix.length;
            var cols = p.matrix[0].length;
            var ox = -(cols * miniStep - GAP) / 2 + MINI / 2;
            var oy = (rows * miniStep - GAP) / 2 - MINI / 2;
            p.matrix.forEach((row, dr) => {
              row.forEach((v, dc) => {
                if (v < 0) return;
                var mini = instantiate(_this2.cellPrefab);
                mini.setPosition(ox + dc * miniStep, oy - dr * miniStep, 0);
                var ui = mini.getComponent(UITransform);

                if (ui) {
                  ui.width = MINI;
                  ui.height = MINI;
                }

                var sp = mini.getComponent(Sprite);
                if (sp) sp.color = PIECE_COLORS[v];
                slot.addChild(mini);
              });
            }); // 直接拖拽模式：槽位本身不要再做“选中放大”。
            // 按下槽位后会隐藏槽位里的原图，并创建一个真正跟手的 DragGhost。

            slot.setScale(new Vec3(1, 1, 1));
            slot.off(Node.EventType.TOUCH_START);
            slot.off(Node.EventType.TOUCH_MOVE);
            slot.off(Node.EventType.TOUCH_END);
            slot.off(Node.EventType.TOUCH_CANCEL);
            var idx = i;
            slot.on(Node.EventType.TOUCH_START, e => {
              _this2.beginDragFromSlot(idx, e);
            }, _this2);
          },
              _ret;

          for (var i = 0; i < 2; i++) {
            _ret = _loop3();
            if (_ret === 0) continue;
          }
        } // ════════════════════════════════════════════════════
        //  候选槽触摸开始 → 立刻进入拖拽
        // ════════════════════════════════════════════════════


        beginDragFromSlot(idx, event) {
          var p = this.pieces[idx];
          if (!p) return;
          event.propagationStopped = true; // 正在拖另一个方块时，先清掉旧拖拽状态

          this.clearPreview();

          if (this.dragGhostNode) {
            this.dragGhostNode.destroy();
            this.dragGhostNode = null;
          }

          this.selectedSlot = idx;
          this.createDragGhost(p); // 重要：不要在这里调用 renderSlots()。
          // renderSlots 会重建候选槽位子节点和监听，容易让拖拽回到“点一下放大”的旧表现。
          // 这里直接隐藏原槽位，屏幕上只保留一个跟手移动的 DragGhost。

          if (this.slotNodes[idx]) {
            this.slotNodes[idx].active = false;
          } // 手指刚按下槽位时，幽灵方块马上出现在手指位置


          this.updateDragByTouch(event);
        } // ════════════════════════════════════════════════════
        //  创建幽灵拖拽节点
        // ════════════════════════════════════════════════════


        createDragGhost(p) {
          var _this$node$parent;

          if (this.dragGhostNode) {
            this.dragGhostNode.destroy();
          } // 幽灵挂在棋盘同级父节点，一般就是 Canvas。
          // 这样不会被棋盘格或候选槽位的坐标系影响。


          this.dragGhostNode = new Node('DragGhost');
          var parent = (_this$node$parent = this.node.parent) != null ? _this$node$parent : this.node;
          parent.addChild(this.dragGhostNode);
          this.dragGhostNode.setSiblingIndex(parent.children.length - 1);
          var rows = p.matrix.length;
          var cols = p.matrix[0].length; // 幽灵用与棋盘相同的 CELL_SIZE，方便对齐

          var ox = -(cols * STEP - CELL_GAP) / 2 + CELL_SIZE / 2;
          var oy = (rows * STEP - CELL_GAP) / 2 - CELL_SIZE / 2;
          p.matrix.forEach((row, dr) => {
            row.forEach((v, dc) => {
              if (v < 0) return;
              var cell = instantiate(this.cellPrefab);
              cell.setPosition(ox + dc * STEP, oy - dr * STEP, 0);
              var ui = cell.getComponent(UITransform);

              if (ui) {
                ui.width = CELL_SIZE;
                ui.height = CELL_SIZE;
              }

              var sp = cell.getComponent(Sprite);

              if (sp) {
                var base = PIECE_COLORS[v];
                sp.color = new Color(base.r, base.g, base.b, 200); // 半透明
              }

              this.dragGhostNode.addChild(cell);
            });
          });
        } // ════════════════════════════════════════════════════
        //  全局触摸移动：更新幽灵位置 + 棋盘预测高亮
        // ════════════════════════════════════════════════════


        onGlobalTouchMove(event) {
          this.updateDragByTouch(event);
        }

        updateDragByTouch(event) {
          var _this$dragGhostNode$p;

          if (this.selectedSlot < 0 || !this.dragGhostNode) return; // 1. 获取触摸点并转换为幽灵节点的本地坐标

          var touchPos = event.getUILocation();
          var parentUITransform = (_this$dragGhostNode$p = this.dragGhostNode.parent) == null ? void 0 : _this$dragGhostNode$p.getComponent(UITransform);
          if (!parentUITransform) return; // 将屏幕坐标转换为幽灵节点父空间的本地坐标

          var ghostLocalPos = parentUITransform.convertToNodeSpaceAR(new Vec3(touchPos.x, touchPos.y, 0));
          this.dragGhostNode.setPosition(ghostLocalPos); // 2. 计算棋盘预测落点

          var boardUI = this.node.getComponent(UITransform);
          if (!boardUI) return; // 获取触摸点在棋盘节点下的本地位置

          var boardLocal = boardUI.convertToNodeSpaceAR(new Vec3(touchPos.x, touchPos.y, 0));
          var p = this.pieces[this.selectedSlot];
          if (!p) return;
          var rows = p.matrix.length;
          var cols = p.matrix[0].length;
          /**
           * 偏移补偿逻辑：
           * ghost 节点中心在方块矩阵的几何中心。
           * 计算 row/col 时要换算到矩阵左上角 [0][0] 的棋盘位置。
           */

          var offsetX = (cols - 1) * STEP / 2;
          var offsetY = (rows - 1) * STEP / 2;
          var col = Math.round((boardLocal.x - this.boardStartX - offsetX) / STEP);
          var row = Math.round((this.boardStartY - boardLocal.y - offsetY) / STEP);
          this.updatePreview(row, col);
        } // ════════════════════════════════════════════════════
        //  全局触摸结束：放置或取消
        // ════════════════════════════════════════════════════


        onGlobalTouchEnd(event) {
          if (this.selectedSlot < 0) return; // 松手瞬间再按最终触点刷新一次落点，避免最后一帧 TOUCH_MOVE 没触发，
          // previewRow / previewCol 还是旧值或无效值。

          this.updateDragByTouch(event);

          if (this.previewRow >= 0 && this.previewCol >= 0) {
            var p = this.pieces[this.selectedSlot];

            if (p && this.canPlace(p.matrix, this.previewRow, this.previewCol)) {
              this.placePiece(this.previewRow, this.previewCol);
              return;
            }
          } // 直接拖拽模式：松手无效就取消，方块回到候选槽位


          this.cancelDrag();
        } // ════════════════════════════════════════════════════
        //  棋盘格点击（兼容旧逻辑，作为备用放置方式）
        // ════════════════════════════════════════════════════


        onCellTap(r, c) {
          if (this.selectedSlot < 0) return;
          var p = this.pieces[this.selectedSlot];
          if (!p) return;
          if (!this.canPlace(p.matrix, r, c)) return;
          this.placePiece(r, c);
        } // ════════════════════════════════════════════════════
        //  棋盘预测高亮更新
        // ════════════════════════════════════════════════════


        updatePreview(row, col) {
          // 先清除旧预览
          this.clearPreview();
          if (this.selectedSlot < 0) return;
          var p = this.pieces[this.selectedSlot];
          if (!p) return;

          if (!this.canPlace(p.matrix, row, col)) {
            this.previewRow = -1;
            this.previewCol = -1;
            return;
          }

          this.previewRow = row;
          this.previewCol = col; // 渲染半透明预测

          p.matrix.forEach((rowArr, dr) => {
            rowArr.forEach((v, dc) => {
              if (v < 0) return;
              var nr = row + dr,
                  nc = col + dc;
              this.setCellColor(nr, nc, v, 140); // 半透明
            });
          });
        }

        clearPreview() {
          for (var r = 0; r < ROWS; r++) for (var c = 0; c < COLS; c++) if (this.boardData[r][c] < 0) this.setCellColor(r, c, -1);

          this.previewRow = -1;
          this.previewCol = -1;
        } // ════════════════════════════════════════════════════
        //  取消拖拽
        // ════════════════════════════════════════════════════


        cancelDrag() {
          this.selectedSlot = -1;
          this.clearPreview();

          if (this.dragGhostNode) {
            this.dragGhostNode.destroy();
            this.dragGhostNode = null;
          }

          this.renderSlots();
        } // ════════════════════════════════════════════════════
        //  放置方块（提取公共逻辑）
        // ════════════════════════════════════════════════════


        placePiece(r, c) {
          var p = this.pieces[this.selectedSlot];
          if (!p) return; // 清除幽灵和预览

          this.clearPreview();

          if (this.dragGhostNode) {
            this.dragGhostNode.destroy();
            this.dragGhostNode = null;
          }

          var placed = 0;
          p.matrix.forEach((row, dr) => row.forEach((v, dc) => {
            if (v < 0) return;
            this.boardData[r + dr][c + dc] = v;
            this.setCellColor(r + dr, c + dc, v);
            placed++;
          }));
          this.score += placed;

          if (this.audioSource && this.placeSound) {
            this.audioSource.playOneShot(this.placeSound);
          }

          this.pieces[this.selectedSlot] = null;
          this.selectedSlot = -1;
          this.checkEliminate();
          if (this.pieces.every(p => p === null)) this.dealPieces();else this.renderSlots();
          this.updateScoreUI();
          if (!this.canAnyPlace()) this.showGameOver();
        } // ════════════════════════════════════════════════════
        //  放置合法性检查
        // ════════════════════════════════════════════════════


        canPlace(matrix, tr, tc) {
          for (var dr = 0; dr < matrix.length; dr++) {
            for (var dc = 0; dc < matrix[0].length; dc++) {
              if (matrix[dr][dc] < 0) continue;
              var nr = tr + dr,
                  nc = tc + dc;
              if (nr < 0 || nr >= ROWS || nc < 0 || nc >= COLS) return false;
              if (this.boardData[nr][nc] >= 0) return false;
            }
          }

          return true;
        }

        canAnyPlace() {
          for (var p of this.pieces) {
            if (!p) continue;

            for (var r = 0; r < ROWS; r++) for (var c = 0; c < COLS; c++) if (this.canPlace(p.matrix, r, c)) return true;
          }

          return false;
        } // ════════════════════════════════════════════════════
        //  消除逻辑
        //  规则：同色方块只要通过上下左右四方向连通，且连通块数量 >= 3，就整片消除。
        //  注意：斜对角不算相邻；十字、L形、T形、横线、竖线都会被识别为同一个连通块。
        // ════════════════════════════════════════════════════


        checkEliminate() {
          var groups = this.findConnectedColorGroups(3);
          if (groups.length === 0) return;

          if (this.audioSource && this.eliminateSound) {
            this.audioSource.playOneShot(this.eliminateSound);
          }

          var toElim = new Set();
          groups.forEach(group => {
            group.forEach(pos => toElim.add(pos.r + "," + pos.c));
          });
          this.score += toElim.size * 2;
          toElim.forEach(key => {
            var [r, c] = key.split(',').map(Number);
            this.boardData[r][c] = -1;
            this.setCellColor(r, c, -1);
          });
        }

        findConnectedColorGroups(minCount) {
          var result = [];
          var visited = Array.from({
            length: ROWS
          }, () => Array(COLS).fill(false));
          var dirs = [{
            r: -1,
            c: 0
          }, // 上
          {
            r: 1,
            c: 0
          }, // 下
          {
            r: 0,
            c: -1
          }, // 左
          {
            r: 0,
            c: 1
          } // 右
          ];

          for (var sr = 0; sr < ROWS; sr++) {
            for (var sc = 0; sc < COLS; sc++) {
              var colorId = this.boardData[sr][sc];
              if (colorId < 0 || visited[sr][sc]) continue;
              var group = [];
              var queue = [{
                r: sr,
                c: sc
              }];
              visited[sr][sc] = true;

              while (queue.length > 0) {
                var cur = queue.shift();
                if (!cur) continue;
                group.push(cur);

                for (var d of dirs) {
                  var nr = cur.r + d.r;
                  var nc = cur.c + d.c;
                  if (nr < 0 || nr >= ROWS || nc < 0 || nc >= COLS) continue;
                  if (visited[nr][nc]) continue;
                  if (this.boardData[nr][nc] !== colorId) continue;
                  visited[nr][nc] = true;
                  queue.push({
                    r: nr,
                    c: nc
                  });
                }
              }

              if (group.length >= minCount) {
                result.push(group);
              }
            }
          }

          return result;
        } // ════════════════════════════════════════════════════
        //  UI 更新
        // ════════════════════════════════════════════════════


        updateScoreUI() {
          if (this.scoreLabel) this.scoreLabel.string = String(this.score);

          if (this.score > this.best) {
            this.best = this.score;
            if (this.bestLabel) this.bestLabel.string = String(this.best);
          }
        }

        showGameOver() {
          if (this.audioSource && this.deathSound) {
            this.audioSource.playOneShot(this.deathSound);
          }

          if (this.gameOverPanel) {
            this.gameOverPanel.active = true;
            if (this.gameOverScoreLabel) this.gameOverScoreLabel.string = "\u5F97\u5206\uFF1A" + this.score;
          }
        } // ════════════════════════════════════════════════════
        //  重启按钮回调
        // ════════════════════════════════════════════════════


        onRestartBtn() {
          if (this.audioSource && this.restartSound) {
            this.audioSource.playOneShot(this.restartSound);
          }

          this.cancelDrag();
          if (this.gameOverPanel) this.gameOverPanel.active = false;

          for (var r = 0; r < ROWS; r++) for (var c = 0; c < COLS; c++) {
            this.boardData[r][c] = -1;
            this.setCellColor(r, c, -1);
          }

          this.score = 0;
          this.updateScoreUI();
          this.dealPieces();
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "cellPrefab", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "piecesArea", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "scoreLabel", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "bestLabel", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "gameOverPanel", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "gameOverScoreLabel", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "audioSource", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor8 = _applyDecoratedDescriptor(_class2.prototype, "placeSound", [_dec9], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor9 = _applyDecoratedDescriptor(_class2.prototype, "eliminateSound", [_dec10], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor10 = _applyDecoratedDescriptor(_class2.prototype, "deathSound", [_dec11], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor11 = _applyDecoratedDescriptor(_class2.prototype, "restartSound", [_dec12], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=e534354d4a29b0bb2da7672226359c0c4f1263f2.js.map