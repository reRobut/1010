System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, Node, Prefab, instantiate, Color, Sprite, Label, UITransform, color, Vec3, _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _crd, ccclass, property, ROWS, COLS, CELL_SIZE, CELL_GAP, STEP, PIECE_COLORS, EMPTY_COLOR, SHAPE_LIBRARY, BoardManager;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  // ─── 矩阵工具函数 ────────────────────────────────────────
  function rotateMatrix(matrix) {
    return matrix[0].map((_, index) => matrix.map(row => row[index]).reverse());
  }

  function mirrorMatrix(matrix) {
    return matrix.map(row => [...row].reverse());
  }

  function weightedRandom(shapes) {
    var total = shapes.reduce((s, x) => s + x.weight, 0);
    var r = Math.random() * total;

    for (var x of shapes) {
      r -= x.weight;
      if (r <= 0) return x;
    }

    return shapes[shapes.length - 1];
  }

  function generateColoredMatrix() {
    var def = weightedRandom(SHAPE_LIBRARY);
    var m = def.matrix.map(r => [...r]);

    if (def.canRotate) {
      var n = Math.floor(Math.random() * 4);

      for (var i = 0; i < n; i++) m = rotateMatrix(m);
    }

    if (def.canMirror && Math.random() < 0.5) m = mirrorMatrix(m);
    var rows = m.length;
    var cols = m[0].length;
    var colored = Array.from({
      length: rows
    }, () => Array(cols).fill(-1));

    for (var r = 0; r < rows; r++) {
      var _loop = function _loop() {
        if (m[r][c] !== 1) return 1; // continue

        var forbidden = new Set();
        if (r > 0 && colored[r - 1][c] >= 0) forbidden.add(colored[r - 1][c]);
        if (c > 0 && colored[r][c - 1] >= 0) forbidden.add(colored[r][c - 1]);
        var available = [0, 1, 2, 3].filter(id => !forbidden.has(id));
        colored[r][c] = available[Math.floor(Math.random() * available.length)];
      };

      for (var c = 0; c < cols; c++) {
        if (_loop()) continue;
      }
    }

    return {
      matrix: colored,
      name: def.name
    };
  } // ─── 主组件 ──────────────────────────────────────────────


  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      Prefab = _cc.Prefab;
      instantiate = _cc.instantiate;
      Color = _cc.Color;
      Sprite = _cc.Sprite;
      Label = _cc.Label;
      UITransform = _cc.UITransform;
      color = _cc.color;
      Vec3 = _cc.Vec3;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "578dc13sU5JopKEpQ5sKIvD", "BoardManager%20-%20Kopie", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node', 'Prefab', 'instantiate', 'Color', 'Sprite', 'Label', 'SpriteFrame', 'UITransform', 'color', 'Vec2', 'Vec3', 'EventTouch', 'Camera', 'Canvas']);

      ({
        ccclass,
        property
      } = _decorator); // ─── 常量 ───────────────────────────────────────────────

      ROWS = 10;
      COLS = 10;
      CELL_SIZE = 58;
      CELL_GAP = 4;
      STEP = CELL_SIZE + CELL_GAP;
      PIECE_COLORS = [color('#E84855'), color('#F4A259'), color('#3BB5C8'), color('#7C6FFF')];
      EMPTY_COLOR = color('#1E1E35'); // ─── 形状库 ─────────────────────────────────────────────

      SHAPE_LIBRARY = [{
        name: "dot",
        matrix: [[1]],
        weight: 10,
        canRotate: false,
        canMirror: false
      }, {
        name: "22full",
        matrix: [[1, 1], [1, 1]],
        weight: 60,
        canRotate: false,
        canMirror: false
      }, {
        name: "5CROSS",
        matrix: [[0, 0, 1, 0, 0], [0, 0, 1, 0, 0], [1, 1, 0, 1, 1], [0, 0, 1, 0, 0], [0, 0, 1, 0, 0]],
        weight: 5,
        canRotate: false,
        canMirror: false
      }, {
        name: "kou",
        matrix: [[1, 1, 1], [1, 0, 1], [1, 1, 1]],
        weight: 25,
        canRotate: false,
        canMirror: false
      }, {
        name: "23L",
        matrix: [[1, 0], [1, 0], [1, 1]],
        weight: 50,
        canRotate: true,
        canMirror: true
      }, {
        name: "longPu",
        matrix: [[0, 1, 0], [0, 1, 0], [1, 1, 1]],
        weight: 25,
        canRotate: false,
        canMirror: false
      }, {
        name: "six",
        matrix: [[1, 0], [1, 1], [1, 1]],
        weight: 40,
        canRotate: true,
        canMirror: true
      }, {
        name: "pu",
        matrix: [[1, 0], [1, 1], [1, 0]],
        weight: 40,
        canRotate: true,
        canMirror: true
      }, {
        name: "3dots",
        matrix: [[1, 0], [1, 1]],
        weight: 70,
        canRotate: true,
        canMirror: true
      }, {
        name: "23Z",
        matrix: [[0, 1, 1], [1, 1, 0]],
        weight: 45,
        canRotate: true,
        canMirror: true
      }, {
        name: "24Z",
        matrix: [[0, 1], [1, 1], [1, 0], [1, 0]],
        weight: 30,
        canRotate: true,
        canMirror: true
      }, {
        name: "34Z",
        matrix: [[1, 1, 0], [0, 1, 0], [0, 1, 0], [0, 1, 1]],
        weight: 10,
        canRotate: true,
        canMirror: true
      }, {
        name: "line2",
        matrix: [[1, 1]],
        weight: 50,
        canRotate: true,
        canMirror: false
      }, {
        name: "line3",
        matrix: [[1, 1, 1]],
        weight: 45,
        canRotate: true,
        canMirror: false
      }, {
        name: "line4",
        matrix: [[1, 1, 1, 1]],
        weight: 15,
        canRotate: true,
        canMirror: false
      }, {
        name: "line5",
        matrix: [[1, 1, 1, 1, 1]],
        weight: 10,
        canRotate: true,
        canMirror: false
      }, {
        name: "stair",
        matrix: [[0, 1, 1], [1, 1, 0], [1, 0, 0]],
        weight: 25,
        canRotate: true,
        canMirror: true
      }];

      _export("BoardManager", BoardManager = (_dec = ccclass('BoardManager'), _dec2 = property(Prefab), _dec3 = property(Node), _dec4 = property(Label), _dec5 = property(Label), _dec6 = property(Node), _dec7 = property(Label), _dec(_class = (_class2 = class BoardManager extends Component {
        constructor() {
          super(...arguments);

          _initializerDefineProperty(this, "cellPrefab", _descriptor, this);

          _initializerDefineProperty(this, "piecesArea", _descriptor2, this);

          _initializerDefineProperty(this, "scoreLabel", _descriptor3, this);

          _initializerDefineProperty(this, "bestLabel", _descriptor4, this);

          _initializerDefineProperty(this, "gameOverPanel", _descriptor5, this);

          _initializerDefineProperty(this, "gameOverScoreLabel", _descriptor6, this);

          // ── 内部状态 ──
          this.boardData = [];
          this.cellNodes = [];
          this.pieces = [null, null];
          this.selectedSlot = -1;
          this.score = 0;
          this.best = 0;
          this.slotNodes = [];
          // ── 拖拽相关 ──

          /** 跟随鼠标的"幽灵"预览节点容器 */
          this.dragGhostNode = null;

          /** 当前预览落点（棋盘行列），-1 表示无效 */
          this.previewRow = -1;
          this.previewCol = -1;

          /** 棋盘左上角第一格的世界坐标（本地坐标系下） */
          this.boardStartX = 0;
          this.boardStartY = 0;
        }

        onLoad() {
          this.initBoard();
          this.slotNodes = [this.piecesArea.getChildByName('Slot0'), this.piecesArea.getChildByName('Slot1')];
          this.dealPieces();
          this.updateScoreUI();
          if (this.gameOverPanel) this.gameOverPanel.active = false; // 计算棋盘起始坐标（与 initBoard 中一致）

          var boardWidth = COLS * STEP - CELL_GAP;
          var boardHeight = ROWS * STEP - CELL_GAP;
          this.boardStartX = -boardWidth / 2 + CELL_SIZE / 2;
          this.boardStartY = boardHeight / 2 - CELL_SIZE / 2; // 在棋盘节点上监听全局触摸移动与结束，用于拖拽

          this.node.on(Node.EventType.TOUCH_MOVE, this.onGlobalTouchMove, this);
          this.node.on(Node.EventType.TOUCH_END, this.onGlobalTouchEnd, this);
          this.node.on(Node.EventType.TOUCH_CANCEL, this.cancelDrag, this);
        }

        onDestroy() {
          this.node.off(Node.EventType.TOUCH_MOVE, this.onGlobalTouchMove, this);
          this.node.off(Node.EventType.TOUCH_END, this.onGlobalTouchEnd, this);
          this.node.off(Node.EventType.TOUCH_CANCEL, this.cancelDrag, this);
        } // ════════════════════════════════════════════════════
        //  棋盘初始化
        // ════════════════════════════════════════════════════


        initBoard() {
          var _this = this;

          this.boardData = Array.from({
            length: ROWS
          }, () => Array(COLS).fill(-1));
          this.cellNodes = Array.from({
            length: ROWS
          }, () => Array(COLS).fill(null));
          var boardWidth = COLS * STEP - CELL_GAP;
          var boardHeight = ROWS * STEP - CELL_GAP;
          var startX = -boardWidth / 2 + CELL_SIZE / 2;
          var startY = boardHeight / 2 - CELL_SIZE / 2;

          for (var r = 0; r < ROWS; r++) {
            var _loop2 = function _loop2() {
              var cell = instantiate(_this.cellPrefab);
              cell.setPosition(startX + c * STEP, startY - r * STEP, 0);
              var ui = cell.getComponent(UITransform);

              if (ui) {
                ui.width = CELL_SIZE;
                ui.height = CELL_SIZE;
              }

              _this.node.addChild(cell);

              _this.cellNodes[r][c] = cell;

              _this.setCellColor(r, c, -1); // 棋盘格点击现在改为：如果正在拖拽则放置


              var row = r,
                  col = c;
              cell.on(Node.EventType.TOUCH_END, () => _this.onCellTap(row, col), _this);
            };

            for (var c = 0; c < COLS; c++) {
              _loop2();
            }
          }
        } // ════════════════════════════════════════════════════
        //  颜色渲染
        // ════════════════════════════════════════════════════


        setCellColor(r, c, colorId, alpha) {
          if (alpha === void 0) {
            alpha = 255;
          }

          var sprite = this.cellNodes[r][c].getComponent(Sprite);
          if (!sprite) return;

          if (colorId >= 0) {
            var base = PIECE_COLORS[colorId];
            sprite.color = new Color(base.r, base.g, base.b, alpha);
          } else {
            sprite.color = EMPTY_COLOR.clone();
          }
        } // ════════════════════════════════════════════════════
        //  候选方块生成与渲染
        // ════════════════════════════════════════════════════


        dealPieces() {
          this.pieces = [generateColoredMatrix(), generateColoredMatrix()];
          this.selectedSlot = -1;
          this.renderSlots();
        }

        renderSlots() {
          var _this2 = this;

          var _loop3 = function _loop3() {
            var slot = _this2.slotNodes[i];
            if (!slot) return 0; // continue

            slot.removeAllChildren();
            var p = _this2.pieces[i];

            if (!p) {
              slot.active = false;
              return 0; // continue
            }

            slot.active = true;
            var MINI = 30;
            var GAP = 2;
            var miniStep = MINI + GAP;
            var rows = p.matrix.length;
            var cols = p.matrix[0].length;
            var ox = -(cols * miniStep - GAP) / 2 + MINI / 2;
            var oy = (rows * miniStep - GAP) / 2 - MINI / 2;
            p.matrix.forEach((row, dr) => {
              row.forEach((v, dc) => {
                if (v < 0) return;
                var mini = instantiate(_this2.cellPrefab);
                mini.setPosition(ox + dc * miniStep, oy - dr * miniStep, 0);
                var ui = mini.getComponent(UITransform);

                if (ui) {
                  ui.width = MINI;
                  ui.height = MINI;
                }

                var sp = mini.getComponent(Sprite);
                if (sp) sp.color = PIECE_COLORS[v];
                slot.addChild(mini);
              });
            }); // 选中状态视觉反馈：缩放

            slot.setScale(_this2.selectedSlot === i ? new Vec3(1.15, 1.15, 1) : new Vec3(1, 1, 1));
            slot.off(Node.EventType.TOUCH_END);
            var idx = i;
            slot.on(Node.EventType.TOUCH_END, e => {
              e.propagationStopped = true; // 防止冒泡到棋盘

              _this2.onSlotTap(idx);
            }, _this2);
          },
              _ret;

          for (var i = 0; i < 2; i++) {
            _ret = _loop3();
            if (_ret === 0) continue;
          }
        } // ════════════════════════════════════════════════════
        //  候选槽点击 → 开始拖拽
        // ════════════════════════════════════════════════════


        onSlotTap(idx) {
          if (!this.pieces[idx]) return;

          if (this.selectedSlot === idx) {
            // 再次点击取消
            this.cancelDrag();
            return;
          } // 切换到新槽


          if (this.dragGhostNode) {
            this.dragGhostNode.destroy();
            this.dragGhostNode = null;
          }

          this.selectedSlot = idx;
          this.renderSlots(); // 更新选中高亮
          // 创建幽灵节点（随鼠标移动的半透明副本）

          this.createDragGhost(this.pieces[idx]);
        } // ════════════════════════════════════════════════════
        //  创建幽灵拖拽节点
        // ════════════════════════════════════════════════════


        createDragGhost(p) {
          var _this$node$parent;

          if (this.dragGhostNode) {
            this.dragGhostNode.destroy();
          } // 幽灵挂在 Canvas 根节点（或棋盘节点），保证层级最高


          this.dragGhostNode = new Node('DragGhost'); // 挂到父节点确保在最上层

          var parent = (_this$node$parent = this.node.parent) != null ? _this$node$parent : this.node;
          parent.addChild(this.dragGhostNode);
          var rows = p.matrix.length;
          var cols = p.matrix[0].length; // 幽灵用与棋盘相同的 CELL_SIZE，方便对齐

          var ox = -(cols * STEP - CELL_GAP) / 2 + CELL_SIZE / 2;
          var oy = (rows * STEP - CELL_GAP) / 2 - CELL_SIZE / 2;
          p.matrix.forEach((row, dr) => {
            row.forEach((v, dc) => {
              if (v < 0) return;
              var cell = instantiate(this.cellPrefab);
              cell.setPosition(ox + dc * STEP, oy - dr * STEP, 0);
              var ui = cell.getComponent(UITransform);

              if (ui) {
                ui.width = CELL_SIZE;
                ui.height = CELL_SIZE;
              }

              var sp = cell.getComponent(Sprite);

              if (sp) {
                var base = PIECE_COLORS[v];
                sp.color = new Color(base.r, base.g, base.b, 200); // 半透明
              }

              this.dragGhostNode.addChild(cell);
            });
          });
        } // ════════════════════════════════════════════════════
        //  全局触摸移动：更新幽灵位置 + 棋盘预测高亮
        // ════════════════════════════════════════════════════


        onGlobalTouchMove(event) {
          var _this$dragGhostNode$p;

          if (this.selectedSlot < 0 || !this.dragGhostNode) return; // 1. 获取触摸点并转换为幽灵节点的本地坐标

          var touchPos = event.getUILocation();
          var parentUITransform = (_this$dragGhostNode$p = this.dragGhostNode.parent) == null ? void 0 : _this$dragGhostNode$p.getComponent(UITransform);
          if (!parentUITransform) return; // 将屏幕坐标转换为幽灵节点父空间的本地坐标

          var ghostLocalPos = parentUITransform.convertToNodeSpaceAR(new Vec3(touchPos.x, touchPos.y, 0));
          this.dragGhostNode.setPosition(ghostLocalPos); // 2. 计算棋盘预测落点

          var boardUI = this.node.getComponent(UITransform);
          if (!boardUI) return; // 获取触摸点在棋盘节点下的本地位置

          var boardLocal = boardUI.convertToNodeSpaceAR(new Vec3(touchPos.x, touchPos.y, 0)); // 【关键修复】：获取当前方块的定义，计算其矩阵中心偏移

          var p = this.pieces[this.selectedSlot];
          if (!p) return;
          var rows = p.matrix.length;
          var cols = p.matrix[0].length;
          /** 
           * 偏移补偿逻辑：
           * 因为 ghost 节点的中心点是 (0,0)，对应的是方块矩阵的几何中心。
           * 我们计算 row/col 时需要对齐到矩阵的 [0][0] 单元格。
           */

          var offsetX = (cols - 1) * STEP / 2;
          var offsetY = (rows - 1) * STEP / 2;
          var col = Math.round((boardLocal.x - this.boardStartX - offsetX) / STEP);
          var row = Math.round((this.boardStartY - boardLocal.y - offsetY) / STEP);
          this.updatePreview(row, col);
        } // ════════════════════════════════════════════════════
        //  全局触摸结束：放置或取消
        // ════════════════════════════════════════════════════


        onGlobalTouchEnd(event) {
          if (this.selectedSlot < 0) return;

          if (this.previewRow >= 0 && this.previewCol >= 0) {
            var p = this.pieces[this.selectedSlot];

            if (p && this.canPlace(p.matrix, this.previewRow, this.previewCol)) {
              this.placePiece(this.previewRow, this.previewCol);
              return;
            }
          } // 落点无效不取消选中，让玩家继续拖

        } // ════════════════════════════════════════════════════
        //  棋盘格点击（兼容旧逻辑，作为备用放置方式）
        // ════════════════════════════════════════════════════


        onCellTap(r, c) {
          if (this.selectedSlot < 0) return;
          var p = this.pieces[this.selectedSlot];
          if (!p) return;
          if (!this.canPlace(p.matrix, r, c)) return;
          this.placePiece(r, c);
        } // ════════════════════════════════════════════════════
        //  棋盘预测高亮更新
        // ════════════════════════════════════════════════════


        updatePreview(row, col) {
          // 先清除旧预览
          this.clearPreview();
          if (this.selectedSlot < 0) return;
          var p = this.pieces[this.selectedSlot];
          if (!p) return;

          if (!this.canPlace(p.matrix, row, col)) {
            this.previewRow = -1;
            this.previewCol = -1;
            return;
          }

          this.previewRow = row;
          this.previewCol = col; // 渲染半透明预测

          p.matrix.forEach((rowArr, dr) => {
            rowArr.forEach((v, dc) => {
              if (v < 0) return;
              var nr = row + dr,
                  nc = col + dc;
              this.setCellColor(nr, nc, v, 140); // 半透明
            });
          });
        }

        clearPreview() {
          for (var r = 0; r < ROWS; r++) for (var c = 0; c < COLS; c++) if (this.boardData[r][c] < 0) this.setCellColor(r, c, -1);

          this.previewRow = -1;
          this.previewCol = -1;
        } // ════════════════════════════════════════════════════
        //  取消拖拽
        // ════════════════════════════════════════════════════


        cancelDrag() {
          this.selectedSlot = -1;
          this.clearPreview();

          if (this.dragGhostNode) {
            this.dragGhostNode.destroy();
            this.dragGhostNode = null;
          }

          this.renderSlots();
        } // ════════════════════════════════════════════════════
        //  放置方块（提取公共逻辑）
        // ════════════════════════════════════════════════════


        placePiece(r, c) {
          var p = this.pieces[this.selectedSlot];
          if (!p) return; // 清除幽灵和预览

          this.clearPreview();

          if (this.dragGhostNode) {
            this.dragGhostNode.destroy();
            this.dragGhostNode = null;
          }

          var placed = 0;
          p.matrix.forEach((row, dr) => row.forEach((v, dc) => {
            if (v < 0) return;
            this.boardData[r + dr][c + dc] = v;
            this.setCellColor(r + dr, c + dc, v);
            placed++;
          }));
          this.score += placed;
          this.pieces[this.selectedSlot] = null;
          this.selectedSlot = -1;
          this.checkEliminate();
          if (this.pieces.every(p => p === null)) this.dealPieces();else this.renderSlots();
          this.updateScoreUI();
          if (!this.canAnyPlace()) this.showGameOver();
        } // ════════════════════════════════════════════════════
        //  放置合法性检查
        // ════════════════════════════════════════════════════


        canPlace(matrix, tr, tc) {
          for (var dr = 0; dr < matrix.length; dr++) {
            for (var dc = 0; dc < matrix[0].length; dc++) {
              if (matrix[dr][dc] < 0) continue;
              var nr = tr + dr,
                  nc = tc + dc;
              if (nr < 0 || nr >= ROWS || nc < 0 || nc >= COLS) return false;
              if (this.boardData[nr][nc] >= 0) return false;
            }
          }

          return true;
        }

        canAnyPlace() {
          for (var p of this.pieces) {
            if (!p) continue;

            for (var r = 0; r < ROWS; r++) for (var c = 0; c < COLS; c++) if (this.canPlace(p.matrix, r, c)) return true;
          }

          return false;
        } // ════════════════════════════════════════════════════
        //  消除逻辑
        // ════════════════════════════════════════════════════


        checkEliminate() {
          var toElim = new Set();

          for (var r = 0; r < ROWS; r++) {
            var groups = this.findGroups(r, 'row');
            groups.forEach(g => g.forEach(k => toElim.add(k)));
          }

          for (var c = 0; c < COLS; c++) {
            var _groups = this.findGroups(c, 'col');

            _groups.forEach(g => g.forEach(k => toElim.add(k)));
          }

          if (toElim.size === 0) return;
          this.score += toElim.size * 2;
          toElim.forEach(key => {
            var [r, c] = key.split(',').map(Number);
            this.boardData[r][c] = -1;
            this.setCellColor(r, c, -1);
          });
        }

        findGroups(idx, dir) {
          var result = [];
          var seq = [];
          var len = dir === 'row' ? COLS : ROWS;

          for (var i = 0; i < len; i++) {
            var r = dir === 'row' ? idx : i;
            var c = dir === 'row' ? i : idx;
            var v = this.boardData[r][c];

            if (v >= 0) {
              if (seq.length > 0 && seq[seq.length - 1].v === v) {
                seq.push({
                  r,
                  c,
                  v
                });
              } else {
                seq = [{
                  r,
                  c,
                  v
                }];
              }

              if (seq.length >= 3) result.push(seq.map(x => x.r + "," + x.c));
            } else {
              seq = [];
            }
          }

          return result;
        } // ════════════════════════════════════════════════════
        //  UI 更新
        // ════════════════════════════════════════════════════


        updateScoreUI() {
          if (this.scoreLabel) this.scoreLabel.string = String(this.score);

          if (this.score > this.best) {
            this.best = this.score;
            if (this.bestLabel) this.bestLabel.string = String(this.best);
          }
        }

        showGameOver() {
          if (this.gameOverPanel) {
            this.gameOverPanel.active = true;
            if (this.gameOverScoreLabel) this.gameOverScoreLabel.string = "\u5F97\u5206\uFF1A" + this.score;
          }
        } // ════════════════════════════════════════════════════
        //  重启按钮回调
        // ════════════════════════════════════════════════════


        onRestartBtn() {
          this.cancelDrag();
          if (this.gameOverPanel) this.gameOverPanel.active = false;

          for (var r = 0; r < ROWS; r++) for (var c = 0; c < COLS; c++) {
            this.boardData[r][c] = -1;
            this.setCellColor(r, c, -1);
          }

          this.score = 0;
          this.updateScoreUI();
          this.dealPieces();
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "cellPrefab", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "piecesArea", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "scoreLabel", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "bestLabel", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "gameOverPanel", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "gameOverScoreLabel", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=248e73fe1403b1fe42efd10fab91948f67597fc7.js.map