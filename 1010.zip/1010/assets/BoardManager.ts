import { _decorator, Component, Node, Prefab, instantiate, Color, Sprite, Label, UITransform, color, Vec3, EventTouch, input, Input, view } from 'cc';
import { AudioClip, AudioSource } from 'cc';
const { ccclass, property } = _decorator;

// ─── 常量 ───────────────────────────────────────────────
const ROWS = 10;
const COLS = 10;

// 改成 let，方便根据屏幕宽度动态计算
let CELL_SIZE = 72;
let CELL_GAP = 5;
let STEP = CELL_SIZE + CELL_GAP;



const SKINS: {
    name: string;
    pieceColors: Color[];
    emptyColor: Color;
}[] = [
    {
        name: '法国',
        pieceColors: [
    color('#88d2ec'),
    color('#DA4167'),
    color('#aa8cc4'),
    color('#083d77')
        ],
        emptyColor: color('#ffffff'),
    },
    {
        name: '德国',
        pieceColors: [
            color('#F77F00'),
            color('#FCBF49'),
            color('#D62828'),
            color('#003049'),
        ],
        emptyColor: color('#ffffff'),
    },
    
    {
        name: '赛博朋克',
        pieceColors: [
            color('#00F5D4'),
            color('#F15BB5'),
            color('#FEE440'),
            color('#9B5DE5'),
        ],
        emptyColor: color('#1E1E35'),
    },{
        name: '自然',
        pieceColors: [
            color('#7f5539'),
            color('#C2A67F'),
            color('#89965f'),
            color('#414833'),
        ],
        emptyColor: color('#ffffff'),
    }
];
let currentSkinIndex = 0;

function getPieceColors(): Color[] {
    return SKINS[currentSkinIndex].pieceColors;
}

function getEmptyColor(): Color {
    return SKINS[currentSkinIndex].emptyColor;
}

// ─── 形状库 ─────────────────────────────────────────────
interface ShapeDef {
    name: string;
    matrix: number[][];
    difficulty: 'easy' | 'middle' | 'hard' | 'hell' | 'heaven';
    canRotate: boolean;
    canMirror: boolean;
}

const DIFFICULTY_WEIGHT: Record<ShapeDef['difficulty'], number> = {
    easy: 60,
    middle: 15,
    hard: 10,
    hell: 5,
    heaven: 20,
};

const SHAPE_LIBRARY: ShapeDef[] = [
    { name: "dot",    matrix: [[1]],                                                        difficulty: 'heaven', canRotate: false, canMirror: false },
    { name: "22full", matrix: [[1,1],[1,1]],                                                difficulty: 'easy', canRotate: false, canMirror: false },
    { name: "5CROSS", matrix: [[0,0,1,0,0],[0,0,1,0,0],[1,1,0,1,1],[0,0,1,0,0],[0,0,1,0,0]], difficulty: 'hell',  canRotate: false, canMirror: false },
    { name: "kou",    matrix: [[1,1,1],[1,0,1],[1,1,1]],                                   difficulty: 'hard', canRotate: false, canMirror: false },
    { name: "23L",    matrix: [[1,0],[1,0],[1,1]],                                         difficulty: 'hard', canRotate: true,  canMirror: true  },
    { name: "longPu", matrix: [[0,1,0],[0,1,0],[1,1,1]],                                   difficulty: 'hard', canRotate: false, canMirror: false },
    { name: "six",    matrix: [[1,0],[1,1],[1,1]],                                         difficulty: 'middle', canRotate: true,  canMirror: true  },
    { name: "pu",     matrix: [[1,0],[1,1],[1,0]],                                         difficulty: 'easy', canRotate: true,  canMirror: true  },
    { name: "3dots",  matrix: [[1,0],[1,1]],                                               difficulty: 'easy', canRotate: true,  canMirror: true  },
    { name: "23Z",    matrix: [[0,1,1],[1,1,0]],                                           difficulty: 'hard', canRotate: true,  canMirror: true  },
    { name: "24Z",    matrix: [[0,1],[1,1],[1,0],[1,0]],                                   difficulty: 'hard', canRotate: true,  canMirror: true  },
    { name: "34Z",    matrix: [[1,1,0],[0,1,0],[0,1,0],[0,1,1]],                           difficulty: 'hell', canRotate: true,  canMirror: true  },
    { name: "line2",  matrix: [[1,1]],                                                     difficulty: 'easy', canRotate: true,  canMirror: false },
    { name: "line3",  matrix: [[1,1,1]],                                                   difficulty: 'middle', canRotate: true,  canMirror: false },
    { name: "line4",  matrix: [[1,1,1,1]],                                                 difficulty: 'hard', canRotate: true,  canMirror: false },
    { name: "line5",  matrix: [[1,1,1,1,1]],                                               difficulty: 'hell', canRotate: true,  canMirror: false },
    { name: "stair",  matrix: [[0,1,1],[1,1,0],[1,0,0]],                                  difficulty: 'hell', canRotate: true,  canMirror: true  },
];

// ─── 矩阵工具函数 ────────────────────────────────────────
function rotateMatrix(matrix: number[][]): number[][] {
    return matrix[0].map((_, index) => matrix.map(row => row[index]).reverse());
}

function mirrorMatrix(matrix: number[][]): number[][] {
    return matrix.map(row => [...row].reverse());
}

function weightedRandom(shapes: ShapeDef[]): ShapeDef {
    const total = shapes.reduce((sum, shape) => {
        return sum + DIFFICULTY_WEIGHT[shape.difficulty];
    }, 0);

    let r = Math.random() * total;

    for (const shape of shapes) {
        r -= DIFFICULTY_WEIGHT[shape.difficulty];
        if (r <= 0) return shape;
    }

    return shapes[shapes.length - 1];
}

function generateColoredMatrix(): { matrix: number[][], name: string } {
    const def = weightedRandom(SHAPE_LIBRARY);
    let m = def.matrix.map(r => [...r]);

    if (def.canRotate) {
        const n = Math.floor(Math.random() * 4);
        for (let i = 0; i < n; i++) m = rotateMatrix(m);
    }

    if (def.canMirror && Math.random() < 0.5) {
        m = mirrorMatrix(m);
    }

    const rows = m.length;
    const cols = m[0].length;
    const colored: number[][] = Array.from({ length: rows }, () => Array(cols).fill(-1));

    for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
            if (m[r][c] !== 1) continue;

            const forbidden = new Set<number>();

            if (r > 0 && colored[r - 1][c] >= 0) forbidden.add(colored[r - 1][c]);
            if (c > 0 && colored[r][c - 1] >= 0) forbidden.add(colored[r][c - 1]);

            const available = [0, 1, 2, 3].filter(id => !forbidden.has(id));
            colored[r][c] = available[Math.floor(Math.random() * available.length)];
        }
    }

    return { matrix: colored, name: def.name };
}

// ─── 主组件 ──────────────────────────────────────────────
@ccclass('BoardManager')
export class BoardManager extends Component {

    @property(Prefab)
    cellPrefab: Prefab = null;

    @property(Node)
    piecesArea: Node = null;

    @property(Label)
    scoreLabel: Label = null;

    @property(Label)
    bestLabel: Label = null;

    @property(Node)
    gameOverPanel: Node = null;

    @property(Label)
    gameOverScoreLabel: Label = null;

    @property(AudioSource)
    audioSource: AudioSource = null;

    @property(AudioClip)
    placeSound: AudioClip = null;

    @property(AudioClip)
    eliminateSound: AudioClip = null;

    @property(AudioClip)
    deathSound: AudioClip = null;

    @property(AudioClip)
    restartSound: AudioClip = null;

    private boardData: number[][] = [];
    private cellNodes: Node[][] = [];
    private pieces: ({ matrix: number[][], name: string } | null)[] = [null, null];
    private selectedSlot: number = -1;
    private score: number = 0;
    private best: number = 0;
    private slotNodes: Node[] = [];

    private dragGhostNode: Node = null;
    private previewRow: number = -1;
    private previewCol: number = -1;
    private boardStartX: number = 0;
    private boardStartY: number = 0;

    onLoad() {
        this.adaptBoardSize();

        this.initBoard();

        this.slotNodes = [
            this.piecesArea.getChildByName('Slot0'),
            this.piecesArea.getChildByName('Slot1'),
        ];

        this.dealPieces();
        this.updateScoreUI();

        if (this.gameOverPanel) this.gameOverPanel.active = false;

        const boardWidth = COLS * STEP - CELL_GAP;
        const boardHeight = ROWS * STEP - CELL_GAP;
        this.boardStartX = -boardWidth / 2 + CELL_SIZE / 2;
        this.boardStartY = boardHeight / 2 - CELL_SIZE / 2;

        input.on(Input.EventType.TOUCH_MOVE, this.onGlobalTouchMove, this);
        input.on(Input.EventType.TOUCH_END, this.onGlobalTouchEnd, this);
        input.on(Input.EventType.TOUCH_CANCEL, this.cancelDrag, this);
    }

    onDestroy() {
        input.off(Input.EventType.TOUCH_MOVE, this.onGlobalTouchMove, this);
        input.off(Input.EventType.TOUCH_END, this.onGlobalTouchEnd, this);
        input.off(Input.EventType.TOUCH_CANCEL, this.cancelDrag, this);
    }

    // 自适应棋盘宽度
    private adaptBoardSize() {
        const visibleSize = view.getVisibleSize();

        // 左右边距，越小棋盘越大
        const horizontalPadding = 60;

        const targetBoardWidth = visibleSize.width - horizontalPadding;

        CELL_GAP = Math.max(3, Math.floor(targetBoardWidth * 0.006));

        CELL_SIZE = Math.floor(
            (targetBoardWidth - CELL_GAP * (COLS - 1)) / COLS
        );

        STEP = CELL_SIZE + CELL_GAP;
    }

private refreshBoardColors() {

    for (let r = 0; r < ROWS; r++) {
        for (let c = 0; c < COLS; c++) {

            this.setCellColor(
                r,
                c,
                this.boardData[r][c]
            );
        }
    }
}

    private initBoard() {
        this.boardData = Array.from({ length: ROWS }, () => Array(COLS).fill(-1));
        this.cellNodes = Array.from({ length: ROWS }, () => Array(COLS).fill(null));

        const boardWidth = COLS * STEP - CELL_GAP;
        const boardHeight = ROWS * STEP - CELL_GAP;
        const startX = -boardWidth / 2 + CELL_SIZE / 2;
        const startY = boardHeight / 2 - CELL_SIZE / 2;

        for (let r = 0; r < ROWS; r++) {
            for (let c = 0; c < COLS; c++) {
                const cell = instantiate(this.cellPrefab);
                cell.setPosition(startX + c * STEP, startY - r * STEP, 0);

                const ui = cell.getComponent(UITransform);
                if (ui) {
                    ui.width = CELL_SIZE;
                    ui.height = CELL_SIZE;
                }

                this.node.addChild(cell);
                this.cellNodes[r][c] = cell;
                this.setCellColor(r, c, -1);

                const row = r;
                const col = c;
                cell.on(Node.EventType.TOUCH_END, () => this.onCellTap(row, col), this);
            }
        }
    }

    private setCellColor(r: number, c: number, colorId: number, alpha: number = 255) {
    if (r < 0 || r >= ROWS || c < 0 || c >= COLS) return;
    if (!this.cellNodes[r] || !this.cellNodes[r][c]) return;

    const sprite = this.cellNodes[r][c].getComponent(Sprite);
    if (!sprite) return;

    if (colorId >= 0) {
        const colors = getPieceColors();
        const base = colors[colorId];

        if (!base) {
            sprite.color = getEmptyColor().clone();
            return;
        }

        sprite.color = new Color(base.r, base.g, base.b, alpha);
    } else {
        sprite.color = getEmptyColor().clone();
    }
}

    private dealPieces() {
        this.pieces = [generateColoredMatrix(), generateColoredMatrix()];
        this.selectedSlot = -1;
        this.renderSlots();
    }

    private renderSlots() {
        for (let i = 0; i < 2; i++) {
            const slot = this.slotNodes[i];
            if (!slot) continue;

            slot.removeAllChildren();

            const p = this.pieces[i];

            if (!p) {
                slot.active = false;
                continue;
            }

            slot.active = true;

            const slotUI = slot.getComponent(UITransform);
                if (slotUI) {
                    slotUI.width = Math.max(260, CELL_SIZE * 4);
                    slotUI.height = Math.max(260, CELL_SIZE * 4);
                }

            // 候选区也根据棋盘大小自动变化
            const MINI = Math.floor(CELL_SIZE * 0.72);
            const GAP = Math.max(2, Math.floor(CELL_GAP * 0.8));
            const miniStep = MINI + GAP;

            const rows = p.matrix.length;
            const cols = p.matrix[0].length;
            const ox = -(cols * miniStep - GAP) / 2 + MINI / 2;
            const oy = (rows * miniStep - GAP) / 2 - MINI / 2;

            p.matrix.forEach((row, dr) => {
                row.forEach((v, dc) => {
                    if (v < 0) return;

                    const mini = instantiate(this.cellPrefab);
                    mini.setPosition(ox + dc * miniStep, oy - dr * miniStep, 0);

                    const ui = mini.getComponent(UITransform);
                    if (ui) {
                        ui.width = MINI;
                        ui.height = MINI;
                    }

                    const sp = mini.getComponent(Sprite);
                    if (sp) sp.color = getPieceColors()[v];

                    slot.addChild(mini);
                });
            });

            slot.setScale(new Vec3(1, 1, 1));

            slot.off(Node.EventType.TOUCH_START);
            slot.off(Node.EventType.TOUCH_MOVE);
            slot.off(Node.EventType.TOUCH_END);
            slot.off(Node.EventType.TOUCH_CANCEL);

            const idx = i;
            slot.on(Node.EventType.TOUCH_START, (e: EventTouch) => {
                this.beginDragFromSlot(idx, e);
            }, this);
        }
    }

    private beginDragFromSlot(idx: number, event: EventTouch) {
        const p = this.pieces[idx];
        if (!p) return;

        event.propagationStopped = true;

        this.clearPreview();

        if (this.dragGhostNode) {
            this.dragGhostNode.destroy();
            this.dragGhostNode = null;
        }

        this.selectedSlot = idx;
        this.createDragGhost(p);

        if (this.slotNodes[idx]) {
            this.slotNodes[idx].active = false;
        }

        this.updateDragByTouch(event);
    }

    private createDragGhost(p: { matrix: number[][], name: string }) {
        if (this.dragGhostNode) {
            this.dragGhostNode.destroy();
        }

        this.dragGhostNode = new Node('DragGhost');

        const parent = this.node.parent ?? this.node;
        parent.addChild(this.dragGhostNode);
        this.dragGhostNode.setSiblingIndex(parent.children.length - 1);

        const rows = p.matrix.length;
        const cols = p.matrix[0].length;

        const ox = -(cols * STEP - CELL_GAP) / 2 + CELL_SIZE / 2;
        const oy = (rows * STEP - CELL_GAP) / 2 - CELL_SIZE / 2;

        p.matrix.forEach((row, dr) => {
            row.forEach((v, dc) => {
                if (v < 0) return;

                const cell = instantiate(this.cellPrefab);
                cell.setPosition(ox + dc * STEP, oy - dr * STEP, 0);

                const ui = cell.getComponent(UITransform);
                if (ui) {
                    ui.width = CELL_SIZE;
                    ui.height = CELL_SIZE;
                }

                const sp = cell.getComponent(Sprite);
                if (sp) {
                    const base = getPieceColors()[v];
                    sp.color = new Color(base.r, base.g, base.b, 200);
                }

                this.dragGhostNode.addChild(cell);
            });
        });
    }

    private onGlobalTouchMove(event: EventTouch) {
        this.updateDragByTouch(event);
    }

    private updateDragByTouch(event: EventTouch) {
        if (this.selectedSlot < 0 || !this.dragGhostNode) return;

        const touchPos = event.getUILocation();

        const parentUITransform = this.dragGhostNode.parent?.getComponent(UITransform);
        if (!parentUITransform) return;

        const ghostLocalPos = parentUITransform.convertToNodeSpaceAR(
            new Vec3(touchPos.x, touchPos.y, 0)
        );

        this.dragGhostNode.setPosition(ghostLocalPos);

        const boardUI = this.node.getComponent(UITransform);
        if (!boardUI) return;

        const boardLocal = boardUI.convertToNodeSpaceAR(
            new Vec3(touchPos.x, touchPos.y, 0)
        );

        const p = this.pieces[this.selectedSlot];
        if (!p) return;

        const rows = p.matrix.length;
        const cols = p.matrix[0].length;

        const offsetX = (cols - 1) * STEP / 2;
        const offsetY = (rows - 1) * STEP / 2;

        const col = Math.round((boardLocal.x - this.boardStartX - offsetX) / STEP);
        const row = Math.round((this.boardStartY - boardLocal.y - offsetY) / STEP);

        this.updatePreview(row, col);
    }

    private onGlobalTouchEnd(event: EventTouch) {
        if (this.selectedSlot < 0) return;

        this.updateDragByTouch(event);

        if (this.previewRow >= 0 && this.previewCol >= 0) {
            const p = this.pieces[this.selectedSlot];

            if (p && this.canPlace(p.matrix, this.previewRow, this.previewCol)) {
                this.placePiece(this.previewRow, this.previewCol);
                return;
            }
        }

        this.cancelDrag();
    }

    private onCellTap(r: number, c: number) {
        if (this.selectedSlot < 0) return;

        const p = this.pieces[this.selectedSlot];
        if (!p) return;

        if (!this.canPlace(p.matrix, r, c)) return;

        this.placePiece(r, c);
    }

    private updatePreview(row: number, col: number) {
        this.clearPreview();

        if (this.selectedSlot < 0) return;

        const p = this.pieces[this.selectedSlot];
        if (!p) return;

        if (!this.canPlace(p.matrix, row, col)) {
            this.previewRow = -1;
            this.previewCol = -1;
            return;
        }

        this.previewRow = row;
        this.previewCol = col;

        p.matrix.forEach((rowArr, dr) => {
            rowArr.forEach((v, dc) => {
                if (v < 0) return;

                const nr = row + dr;
                const nc = col + dc;

                this.setCellColor(nr, nc, v, 140);
            });
        });
    }

    private clearPreview() {
        for (let r = 0; r < ROWS; r++) {
            for (let c = 0; c < COLS; c++) {
                if (this.boardData[r][c] < 0) {
                    this.setCellColor(r, c, -1);
                }
            }
        }

        this.previewRow = -1;
        this.previewCol = -1;
    }

    private cancelDrag() {
        this.selectedSlot = -1;
        this.clearPreview();

        if (this.dragGhostNode) {
            this.dragGhostNode.destroy();
            this.dragGhostNode = null;
        }

        this.renderSlots();
    }

    private placePiece(r: number, c: number) {
        const p = this.pieces[this.selectedSlot];
        if (!p) return;

        this.clearPreview();

        if (this.dragGhostNode) {
            this.dragGhostNode.destroy();
            this.dragGhostNode = null;
        }

        let placed = 0;

        p.matrix.forEach((row, dr) => {
            row.forEach((v, dc) => {
                if (v < 0) return;

                this.boardData[r + dr][c + dc] = v;
                this.setCellColor(r + dr, c + dc, v);
                placed++;
            });
        });

        this.score += placed;

        if (this.audioSource && this.placeSound) {
            this.audioSource.playOneShot(this.placeSound);
        }

        this.pieces[this.selectedSlot] = null;
        this.selectedSlot = -1;

        this.checkEliminate();

        if (this.pieces.every(p => p === null)) {
            this.dealPieces();
        } else {
            this.renderSlots();
        }

        this.updateScoreUI();

        if (!this.canAnyPlace()) {
            this.showGameOver();
        }
    }

    private canPlace(matrix: number[][], tr: number, tc: number): boolean {
        for (let dr = 0; dr < matrix.length; dr++) {
            for (let dc = 0; dc < matrix[0].length; dc++) {
                if (matrix[dr][dc] < 0) continue;

                const nr = tr + dr;
                const nc = tc + dc;

                if (nr < 0 || nr >= ROWS || nc < 0 || nc >= COLS) return false;
                if (this.boardData[nr][nc] >= 0) return false;
            }
        }

        return true;
    }

    private canAnyPlace(): boolean {
        for (const p of this.pieces) {
            if (!p) continue;

            for (let r = 0; r < ROWS; r++) {
                for (let c = 0; c < COLS; c++) {
                    if (this.canPlace(p.matrix, r, c)) return true;
                }
            }
        }

        return false;
    }

    private checkEliminate() {
        const groups = this.findConnectedColorGroups(3);

        if (groups.length === 0) return;

        if (this.audioSource && this.eliminateSound) {
            this.audioSource.playOneShot(this.eliminateSound);
        }

        const toElim = new Set<string>();

        groups.forEach(group => {
            group.forEach(pos => toElim.add(`${pos.r},${pos.c}`));
        });

        this.score += toElim.size * 2;

        toElim.forEach(key => {
            const [r, c] = key.split(',').map(Number);
            this.boardData[r][c] = -1;
            this.setCellColor(r, c, -1);
        });
    }

    private findConnectedColorGroups(minCount: number): { r: number, c: number }[][] {
        const result: { r: number, c: number }[][] = [];

        const visited: boolean[][] = Array.from(
            { length: ROWS },
            () => Array(COLS).fill(false)
        );

        const dirs = [
            { r: -1, c: 0 },
            { r: 1,  c: 0 },
            { r: 0,  c: -1 },
            { r: 0,  c: 1 },
        ];

        for (let sr = 0; sr < ROWS; sr++) {
            for (let sc = 0; sc < COLS; sc++) {
                const colorId = this.boardData[sr][sc];

                if (colorId < 0 || visited[sr][sc]) continue;

                const group: { r: number, c: number }[] = [];
                const queue: { r: number, c: number }[] = [{ r: sr, c: sc }];

                visited[sr][sc] = true;

                while (queue.length > 0) {
                    const cur = queue.shift();
                    if (!cur) continue;

                    group.push(cur);

                    for (const d of dirs) {
                        const nr = cur.r + d.r;
                        const nc = cur.c + d.c;

                        if (nr < 0 || nr >= ROWS || nc < 0 || nc >= COLS) continue;
                        if (visited[nr][nc]) continue;
                        if (this.boardData[nr][nc] !== colorId) continue;

                        visited[nr][nc] = true;
                        queue.push({ r: nr, c: nc });
                    }
                }

                if (group.length >= minCount) {
                    result.push(group);
                }
            }
        }

        return result;
    }

    private updateScoreUI() {
        if (this.scoreLabel) {
            this.scoreLabel.string = String(this.score);
        }

        if (this.score > this.best) {
            this.best = this.score;

            if (this.bestLabel) {
                this.bestLabel.string = String(this.best);
            }
        }
    }

    private showGameOver() {
        if (this.audioSource && this.deathSound) {
            this.audioSource.playOneShot(this.deathSound);
        }

        if (this.gameOverPanel) {
            this.gameOverPanel.active = true;

            if (this.gameOverScoreLabel) {
                this.gameOverScoreLabel.string = `得分：${this.score}`;
            }
        }
    }
public onSkinBtn() {

    currentSkinIndex++;

    if (currentSkinIndex >= SKINS.length) {
        currentSkinIndex = 0;
    }

    this.refreshBoardColors();
    this.renderSlots();
}
    public onRestartBtn() {
        if (this.audioSource && this.restartSound) {
            this.audioSource.playOneShot(this.restartSound);
        }

        this.cancelDrag();

        if (this.gameOverPanel) {
            this.gameOverPanel.active = false;
        }

        for (let r = 0; r < ROWS; r++) {
            for (let c = 0; c < COLS; c++) {
                this.boardData[r][c] = -1;
                this.setCellColor(r, c, -1);
            }
        }

        this.score = 0;
        this.updateScoreUI();
        this.dealPieces();
    }
}