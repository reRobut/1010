import { _decorator, Component, Node, Prefab, instantiate, Color, Sprite, Label, SpriteFrame, UITransform, color, Vec2, Vec3, EventTouch, input, Input } from 'cc';
import { AudioClip, AudioSource } from 'cc';
const { ccclass, property } = _decorator;

// ─── 常量 ───────────────────────────────────────────────
const ROWS = 10;
const COLS = 10;
const CELL_SIZE = 58;
const CELL_GAP = 4;
const STEP = CELL_SIZE + CELL_GAP;

const PIECE_COLORS: Color[] = [
    color('#88d2ec'),
    color('#DA4167'),
    color('#aa8cc4'),
    color('#083d77'),
];

const EMPTY_COLOR: Color = color('#ffffff');

// ─── 形状库 ─────────────────────────────────────────────
interface ShapeDef {
    name: string;
    matrix: number[][];
    difficulty: 'easy' | 'middle' | 'hard'| 'hell'| 'heaven';
    canRotate: boolean;
    canMirror: boolean;
}

const DIFFICULTY_WEIGHT: Record<ShapeDef['difficulty'], number> = {
    easy: 60,
    middle: 15,
    hard: 15,
    hell: 10,
    heaven: 20,
};

const SHAPE_LIBRARY: ShapeDef[] = [
    { name: "dot",    matrix: [[1]],                                                         difficulty: 'heaven', canRotate: false, canMirror: false },
    { name: "22full", matrix: [[1,1],[1,1]],                                                 difficulty: 'easy', canRotate: false, canMirror: false },
    { name: "5CROSS", matrix: [[0,0,1,0,0],[0,0,1,0,0],[1,1,0,1,1],[0,0,1,0,0],[0,0,1,0,0]],  difficulty: 'hell',  canRotate: false, canMirror: false },
    { name: "kou",    matrix: [[1,1,1],[1,0,1],[1,1,1]],                                    difficulty: 'hard', canRotate: false, canMirror: false },
    { name: "23L",    matrix: [[1,0],[1,0],[1,1]],                                           difficulty: 'hard', canRotate: true,  canMirror: true  },
    { name: "longPu", matrix: [[0,1,0],[0,1,0],[1,1,1]],                                    difficulty: 'hard', canRotate: false, canMirror: false },
    { name: "six",    matrix: [[1,0],[1,1],[1,1]],                                           difficulty: 'middle', canRotate: true,  canMirror: true  },
    { name: "pu",     matrix: [[1,0],[1,1],[1,0]],                                           difficulty: 'easy', canRotate: true,  canMirror: true  },
    { name: "3dots",  matrix: [[1,0],[1,1]],                                                 difficulty: 'easy', canRotate: true,  canMirror: true  },
    { name: "23Z",    matrix: [[0,1,1],[1,1,0]],                                             difficulty: 'hard', canRotate: true,  canMirror: true  },
    { name: "24Z",    matrix: [[0,1],[1,1],[1,0],[1,0]],                                     difficulty: 'hard', canRotate: true,  canMirror: true  },
    { name: "34Z",    matrix: [[1,1,0],[0,1,0],[0,1,0],[0,1,1]],                             difficulty: 'hell', canRotate: true,  canMirror: true  },
    { name: "line2",  matrix: [[1,1]],                                                       difficulty: 'easy', canRotate: true,  canMirror: false },
    { name: "line3",  matrix: [[1,1,1]],                                                    difficulty: 'middle', canRotate: true,  canMirror: false },
    { name: "line4",  matrix: [[1,1,1,1]],                                                  difficulty: 'hard', canRotate: true,  canMirror: false },
    { name: "line5",  matrix: [[1,1,1,1,1]],                                                difficulty: 'hell', canRotate: true,  canMirror: false },
    { name: "stair",  matrix: [[0,1,1],[1,1,0],[1,0,0]],                                   difficulty: 'hell', canRotate: true,  canMirror: true  },
];

// ─── 矩阵工具函数 ────────────────────────────────────────
function rotateMatrix(matrix: number[][]): number[][] {
    return matrix[0].map((_, index) => matrix.map(row => row[index]).reverse());
}

function mirrorMatrix(matrix: number[][]): number[][] {
    return matrix.map(row => [...row].reverse());
}



function weightedRandom(shapes: ShapeDef[]): ShapeDef {
    const total = shapes.reduce((sum, shape) => {
        return sum + DIFFICULTY_WEIGHT[shape.difficulty];
    }, 0);

    let r = Math.random() * total;

    for (const shape of shapes) {
        r -= DIFFICULTY_WEIGHT[shape.difficulty];
        if (r <= 0) {
            return shape;
        }
    }

    return shapes[shapes.length - 1];
}

function generateColoredMatrix(): { matrix: number[][], name: string } {
    const def = weightedRandom(SHAPE_LIBRARY);
    let m = def.matrix.map(r => [...r]);
    if (def.canRotate) {
        const n = Math.floor(Math.random() * 4);
        for (let i = 0; i < n; i++) m = rotateMatrix(m);
    }
    if (def.canMirror && Math.random() < 0.5) m = mirrorMatrix(m);

    const rows = m.length;
    const cols = m[0].length;
    const colored: number[][] = Array.from({ length: rows }, () => Array(cols).fill(-1));

    for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
            if (m[r][c] !== 1) continue;
            const forbidden = new Set<number>();
            if (r > 0 && colored[r-1][c] >= 0) forbidden.add(colored[r-1][c]);
            if (c > 0 && colored[r][c-1] >= 0) forbidden.add(colored[r][c-1]);
            const available = [0, 1, 2, 3].filter(id => !forbidden.has(id));
            colored[r][c] = available[Math.floor(Math.random() * available.length)];
        }
    }

    return { matrix: colored, name: def.name };
}

// ─── 主组件 ──────────────────────────────────────────────
@ccclass('BoardManager')
export class BoardManager extends Component {

    @property(Prefab)
    cellPrefab: Prefab = null;

    @property(Node)
    piecesArea: Node = null;

    @property(Label)
    scoreLabel: Label = null;

    @property(Label)
    bestLabel: Label = null;

    @property(Node)
    gameOverPanel: Node = null;

    @property(Label)
    gameOverScoreLabel: Label = null;

    @property(AudioSource)
    audioSource: AudioSource = null;

    @property(AudioClip)
    placeSound: AudioClip = null;

    @property(AudioClip)
    eliminateSound: AudioClip = null;

    @property(AudioClip)
    deathSound: AudioClip = null;

    @property(AudioClip)
    restartSound: AudioClip = null;

    // ── 内部状态 ──
    private boardData: number[][] = [];
    private cellNodes: Node[][] = [];
    private pieces: ({ matrix: number[][], name: string } | null)[] = [null, null];
    private selectedSlot: number = -1;
    private score: number = 0;
    private best: number = 0;
    private slotNodes: Node[] = [];

    // ── 拖拽相关 ──
    /** 跟随鼠标的"幽灵"预览节点容器 */
    private dragGhostNode: Node = null;
    /** 当前预览落点（棋盘行列），-1 表示无效 */
    private previewRow: number = -1;
    private previewCol: number = -1;
    /** 棋盘左上角第一格的世界坐标（本地坐标系下） */
    private boardStartX: number = 0;
    private boardStartY: number = 0;

    onLoad() {
        this.initBoard();
        this.slotNodes = [
            this.piecesArea.getChildByName('Slot0'),
            this.piecesArea.getChildByName('Slot1'),
        ];
        this.dealPieces();
        this.updateScoreUI();
        if (this.gameOverPanel) this.gameOverPanel.active = false;

        // 计算棋盘起始坐标（与 initBoard 中一致）
        const boardWidth = COLS * STEP - CELL_GAP;
        const boardHeight = ROWS * STEP - CELL_GAP;
        this.boardStartX = -boardWidth / 2 + CELL_SIZE / 2;
        this.boardStartY = boardHeight / 2 - CELL_SIZE / 2;

        // 用 input 监听全局触摸。
        // 注意：拖拽从 Slot 开始后，手指通常会离开 Slot/Board 节点范围，
        // 只监听 this.node 或 slot 容易收不到 TOUCH_END，导致松手后无法真正放置。
        input.on(Input.EventType.TOUCH_MOVE, this.onGlobalTouchMove, this);
        input.on(Input.EventType.TOUCH_END,  this.onGlobalTouchEnd,  this);
        input.on(Input.EventType.TOUCH_CANCEL, this.cancelDrag, this);
    }

    onDestroy() {
        input.off(Input.EventType.TOUCH_MOVE, this.onGlobalTouchMove, this);
        input.off(Input.EventType.TOUCH_END,  this.onGlobalTouchEnd,  this);
        input.off(Input.EventType.TOUCH_CANCEL, this.cancelDrag, this);
    }

    // ════════════════════════════════════════════════════
    //  棋盘初始化
    // ════════════════════════════════════════════════════
    private initBoard() {
        this.boardData = Array.from({ length: ROWS }, () => Array(COLS).fill(-1));
        this.cellNodes = Array.from({ length: ROWS }, () => Array(COLS).fill(null));

        const boardWidth = COLS * STEP - CELL_GAP;
        const boardHeight = ROWS * STEP - CELL_GAP;
        const startX = -boardWidth / 2 + CELL_SIZE / 2;
        const startY = boardHeight / 2 - CELL_SIZE / 2;

        for (let r = 0; r < ROWS; r++) {
            for (let c = 0; c < COLS; c++) {
                const cell = instantiate(this.cellPrefab);
                cell.setPosition(startX + c * STEP, startY - r * STEP, 0);

                const ui = cell.getComponent(UITransform);
                if (ui) { ui.width = CELL_SIZE; ui.height = CELL_SIZE; }

                this.node.addChild(cell);
                this.cellNodes[r][c] = cell;
                this.setCellColor(r, c, -1);

                // 棋盘格点击现在改为：如果正在拖拽则放置
                const row = r, col = c;
                cell.on(Node.EventType.TOUCH_END, () => this.onCellTap(row, col), this);
            }
        }
    }

    // ════════════════════════════════════════════════════
    //  颜色渲染
    // ════════════════════════════════════════════════════
    private setCellColor(r: number, c: number, colorId: number, alpha: number = 255) {
        const sprite = this.cellNodes[r][c].getComponent(Sprite);
        if (!sprite) return;
        if (colorId >= 0) {
            const base = PIECE_COLORS[colorId];
            sprite.color = new Color(base.r, base.g, base.b, alpha);
        } else {
            sprite.color = EMPTY_COLOR.clone();
        }
    }

    // ════════════════════════════════════════════════════
    //  候选方块生成与渲染
    // ════════════════════════════════════════════════════
    private dealPieces() {
        this.pieces = [generateColoredMatrix(), generateColoredMatrix()];
        this.selectedSlot = -1;
        this.renderSlots();
    }

    private renderSlots() {
        for (let i = 0; i < 2; i++) {
            const slot = this.slotNodes[i];
            if (!slot) continue;
            slot.removeAllChildren();

            const p = this.pieces[i];
            if (!p) { slot.active = false; continue; }
            slot.active = true;

            const MINI = 40;
            const GAP = 2;
            const miniStep = MINI + GAP;
            const rows = p.matrix.length;
            const cols = p.matrix[0].length;
            const ox = -(cols * miniStep - GAP) / 2 + MINI / 2;
            const oy = (rows * miniStep - GAP) / 2 - MINI / 2;

            p.matrix.forEach((row, dr) => {
                row.forEach((v, dc) => {
                    if (v < 0) return;
                    const mini = instantiate(this.cellPrefab);
                    mini.setPosition(ox + dc * miniStep, oy - dr * miniStep, 0);
                    const ui = mini.getComponent(UITransform);
                    if (ui) { ui.width = MINI; ui.height = MINI; }
                    const sp = mini.getComponent(Sprite);
                    if (sp) sp.color = PIECE_COLORS[v];
                    slot.addChild(mini);
                });
            });

            // 直接拖拽模式：槽位本身不要再做“选中放大”。
            // 按下槽位后会隐藏槽位里的原图，并创建一个真正跟手的 DragGhost。
            slot.setScale(new Vec3(1, 1, 1));

            slot.off(Node.EventType.TOUCH_START);
            slot.off(Node.EventType.TOUCH_MOVE);
            slot.off(Node.EventType.TOUCH_END);
            slot.off(Node.EventType.TOUCH_CANCEL);

            const idx = i;
            slot.on(Node.EventType.TOUCH_START, (e: EventTouch) => {
                this.beginDragFromSlot(idx, e);
            }, this);
        }
    }

    // ════════════════════════════════════════════════════
    //  候选槽触摸开始 → 立刻进入拖拽
    // ════════════════════════════════════════════════════
    private beginDragFromSlot(idx: number, event: EventTouch) {
        const p = this.pieces[idx];
        if (!p) return;

        event.propagationStopped = true;

        // 正在拖另一个方块时，先清掉旧拖拽状态
        this.clearPreview();
        if (this.dragGhostNode) {
            this.dragGhostNode.destroy();
            this.dragGhostNode = null;
        }

        this.selectedSlot = idx;
        this.createDragGhost(p);

        // 重要：不要在这里调用 renderSlots()。
        // renderSlots 会重建候选槽位子节点和监听，容易让拖拽回到“点一下放大”的旧表现。
        // 这里直接隐藏原槽位，屏幕上只保留一个跟手移动的 DragGhost。
        if (this.slotNodes[idx]) {
            this.slotNodes[idx].active = false;
        }

        // 手指刚按下槽位时，幽灵方块马上出现在手指位置
        this.updateDragByTouch(event);
    }

    // ════════════════════════════════════════════════════
    //  创建幽灵拖拽节点
    // ════════════════════════════════════════════════════
    private createDragGhost(p: { matrix: number[][], name: string }) {
        if (this.dragGhostNode) {
            this.dragGhostNode.destroy();
        }

        // 幽灵挂在棋盘同级父节点，一般就是 Canvas。
        // 这样不会被棋盘格或候选槽位的坐标系影响。
        this.dragGhostNode = new Node('DragGhost');
        const parent = this.node.parent ?? this.node;
        parent.addChild(this.dragGhostNode);
        this.dragGhostNode.setSiblingIndex(parent.children.length - 1);

        const rows = p.matrix.length;
        const cols = p.matrix[0].length;
        // 幽灵用与棋盘相同的 CELL_SIZE，方便对齐
        const ox = -(cols * STEP - CELL_GAP) / 2 + CELL_SIZE / 2;
        const oy = (rows * STEP - CELL_GAP) / 2 - CELL_SIZE / 2;

        p.matrix.forEach((row, dr) => {
            row.forEach((v, dc) => {
                if (v < 0) return;
                const cell = instantiate(this.cellPrefab);
                cell.setPosition(ox + dc * STEP, oy - dr * STEP, 0);
                const ui = cell.getComponent(UITransform);
                if (ui) { ui.width = CELL_SIZE; ui.height = CELL_SIZE; }
                const sp = cell.getComponent(Sprite);
                if (sp) {
                    const base = PIECE_COLORS[v];
                    sp.color = new Color(base.r, base.g, base.b, 200); // 半透明
                }
                this.dragGhostNode.addChild(cell);
            });
        });
    }

    // ════════════════════════════════════════════════════
    //  全局触摸移动：更新幽灵位置 + 棋盘预测高亮
    // ════════════════════════════════════════════════════
    private onGlobalTouchMove(event: EventTouch) {
        this.updateDragByTouch(event);
    }

    private updateDragByTouch(event: EventTouch) {
        if (this.selectedSlot < 0 || !this.dragGhostNode) return;

        // 1. 获取触摸点并转换为幽灵节点的本地坐标
        const touchPos = event.getUILocation();
        const parentUITransform = this.dragGhostNode.parent?.getComponent(UITransform);
        if (!parentUITransform) return;

        // 将屏幕坐标转换为幽灵节点父空间的本地坐标
        const ghostLocalPos = parentUITransform.convertToNodeSpaceAR(new Vec3(touchPos.x, touchPos.y, 0));
        this.dragGhostNode.setPosition(ghostLocalPos);

        // 2. 计算棋盘预测落点
        const boardUI = this.node.getComponent(UITransform);
        if (!boardUI) return;

        // 获取触摸点在棋盘节点下的本地位置
        const boardLocal = boardUI.convertToNodeSpaceAR(new Vec3(touchPos.x, touchPos.y, 0));

        const p = this.pieces[this.selectedSlot];
        if (!p) return;

        const rows = p.matrix.length;
        const cols = p.matrix[0].length;

        /**
         * 偏移补偿逻辑：
         * ghost 节点中心在方块矩阵的几何中心。
         * 计算 row/col 时要换算到矩阵左上角 [0][0] 的棋盘位置。
         */
        const offsetX = (cols - 1) * STEP / 2;
        const offsetY = (rows - 1) * STEP / 2;

        const col = Math.round((boardLocal.x - this.boardStartX - offsetX) / STEP);
        const row = Math.round((this.boardStartY - boardLocal.y - offsetY) / STEP);

        this.updatePreview(row, col);
    }
    // ════════════════════════════════════════════════════
    //  全局触摸结束：放置或取消
    // ════════════════════════════════════════════════════
    private onGlobalTouchEnd(event: EventTouch) {
        if (this.selectedSlot < 0) return;

        // 松手瞬间再按最终触点刷新一次落点，避免最后一帧 TOUCH_MOVE 没触发，
        // previewRow / previewCol 还是旧值或无效值。
        this.updateDragByTouch(event);

        if (this.previewRow >= 0 && this.previewCol >= 0) {
            const p = this.pieces[this.selectedSlot];
            if (p && this.canPlace(p.matrix, this.previewRow, this.previewCol)) {
                this.placePiece(this.previewRow, this.previewCol);
                return;
            }
        }
        // 直接拖拽模式：松手无效就取消，方块回到候选槽位
        this.cancelDrag();
    }

    // ════════════════════════════════════════════════════
    //  棋盘格点击（兼容旧逻辑，作为备用放置方式）
    // ════════════════════════════════════════════════════
    private onCellTap(r: number, c: number) {
        if (this.selectedSlot < 0) return;
        const p = this.pieces[this.selectedSlot];
        if (!p) return;
        if (!this.canPlace(p.matrix, r, c)) return;
        this.placePiece(r, c);
    }

    // ════════════════════════════════════════════════════
    //  棋盘预测高亮更新
    // ════════════════════════════════════════════════════
    private updatePreview(row: number, col: number) {
        // 先清除旧预览
        this.clearPreview();

        if (this.selectedSlot < 0) return;
        const p = this.pieces[this.selectedSlot];
        if (!p) return;

        if (!this.canPlace(p.matrix, row, col)) {
            this.previewRow = -1;
            this.previewCol = -1;
            return;
        }

        this.previewRow = row;
        this.previewCol = col;

        // 渲染半透明预测
        p.matrix.forEach((rowArr, dr) => {
            rowArr.forEach((v, dc) => {
                if (v < 0) return;
                const nr = row + dr, nc = col + dc;
                this.setCellColor(nr, nc, v, 140); // 半透明
            });
        });
    }

    private clearPreview() {
        for (let r = 0; r < ROWS; r++)
            for (let c = 0; c < COLS; c++)
                if (this.boardData[r][c] < 0)
                    this.setCellColor(r, c, -1);
        this.previewRow = -1;
        this.previewCol = -1;
    }

    // ════════════════════════════════════════════════════
    //  取消拖拽
    // ════════════════════════════════════════════════════
    private cancelDrag() {
        this.selectedSlot = -1;
        this.clearPreview();
        if (this.dragGhostNode) {
            this.dragGhostNode.destroy();
            this.dragGhostNode = null;
        }
        this.renderSlots();
    }

    // ════════════════════════════════════════════════════
    //  放置方块（提取公共逻辑）
    // ════════════════════════════════════════════════════
    private placePiece(r: number, c: number) {
        const p = this.pieces[this.selectedSlot];
        if (!p) return;

        // 清除幽灵和预览
        this.clearPreview();
        if (this.dragGhostNode) {
            this.dragGhostNode.destroy();
            this.dragGhostNode = null;
        }

        let placed = 0;
        p.matrix.forEach((row, dr) => row.forEach((v, dc) => {
            if (v < 0) return;
            this.boardData[r + dr][c + dc] = v;
            this.setCellColor(r + dr, c + dc, v);
            placed++;
        }));
        this.score += placed;

        if (this.audioSource && this.placeSound) {
            this.audioSource.playOneShot(this.placeSound);
        }

        this.pieces[this.selectedSlot] = null;
        this.selectedSlot = -1;

        this.checkEliminate();

        if (this.pieces.every(p => p === null)) this.dealPieces();
        else this.renderSlots();

        this.updateScoreUI();

        if (!this.canAnyPlace()) this.showGameOver();
    }

    // ════════════════════════════════════════════════════
    //  放置合法性检查
    // ════════════════════════════════════════════════════
    private canPlace(matrix: number[][], tr: number, tc: number): boolean {
        for (let dr = 0; dr < matrix.length; dr++) {
            for (let dc = 0; dc < matrix[0].length; dc++) {
                if (matrix[dr][dc] < 0) continue;
                const nr = tr + dr, nc = tc + dc;
                if (nr < 0 || nr >= ROWS || nc < 0 || nc >= COLS) return false;
                if (this.boardData[nr][nc] >= 0) return false;
            }
        }
        return true;
    }

    private canAnyPlace(): boolean {
        for (const p of this.pieces) {
            if (!p) continue;
            for (let r = 0; r < ROWS; r++)
                for (let c = 0; c < COLS; c++)
                    if (this.canPlace(p.matrix, r, c)) return true;
        }
        return false;
    }

    // ════════════════════════════════════════════════════
    //  消除逻辑
    //  规则：同色方块只要通过上下左右四方向连通，且连通块数量 >= 3，就整片消除。
    //  注意：斜对角不算相邻；十字、L形、T形、横线、竖线都会被识别为同一个连通块。
    // ════════════════════════════════════════════════════
    private checkEliminate() {
    const groups = this.findConnectedColorGroups(3);
    if (groups.length === 0) return;

    if (this.audioSource && this.eliminateSound) {
        this.audioSource.playOneShot(this.eliminateSound);
    }

    const toElim = new Set<string>();

    groups.forEach(group => {
        group.forEach(pos => toElim.add(`${pos.r},${pos.c}`));
    });

    this.score += toElim.size * 2;

    toElim.forEach(key => {
        const [r, c] = key.split(',').map(Number);
        this.boardData[r][c] = -1;
        this.setCellColor(r, c, -1);
    });
}

    private findConnectedColorGroups(minCount: number): { r: number, c: number }[][] {
        const result: { r: number, c: number }[][] = [];
        const visited: boolean[][] = Array.from({ length: ROWS }, () => Array(COLS).fill(false));
        const dirs = [
            { r: -1, c: 0 }, // 上
            { r: 1,  c: 0 }, // 下
            { r: 0,  c: -1 }, // 左
            { r: 0,  c: 1 }, // 右
        ];

        for (let sr = 0; sr < ROWS; sr++) {
            for (let sc = 0; sc < COLS; sc++) {
                const colorId = this.boardData[sr][sc];
                if (colorId < 0 || visited[sr][sc]) continue;

                const group: { r: number, c: number }[] = [];
                const queue: { r: number, c: number }[] = [{ r: sr, c: sc }];
                visited[sr][sc] = true;

                while (queue.length > 0) {
                    const cur = queue.shift();
                    if (!cur) continue;
                    group.push(cur);

                    for (const d of dirs) {
                        const nr = cur.r + d.r;
                        const nc = cur.c + d.c;
                        if (nr < 0 || nr >= ROWS || nc < 0 || nc >= COLS) continue;
                        if (visited[nr][nc]) continue;
                        if (this.boardData[nr][nc] !== colorId) continue;

                        visited[nr][nc] = true;
                        queue.push({ r: nr, c: nc });
                    }
                }

                if (group.length >= minCount) {
                    result.push(group);
                }
            }
        }

        return result;
    }

    // ════════════════════════════════════════════════════
    //  UI 更新
    // ════════════════════════════════════════════════════
    private updateScoreUI() {
        if (this.scoreLabel) this.scoreLabel.string = String(this.score);
        if (this.score > this.best) {
            this.best = this.score;
            if (this.bestLabel) this.bestLabel.string = String(this.best);
        }
    }

    private showGameOver() {
    if (this.audioSource && this.deathSound) {
        this.audioSource.playOneShot(this.deathSound);
    }

    if (this.gameOverPanel) {
        this.gameOverPanel.active = true;
        if (this.gameOverScoreLabel)
            this.gameOverScoreLabel.string = `得分：${this.score}`;
    }
}

    // ════════════════════════════════════════════════════
    //  重启按钮回调
    // ════════════════════════════════════════════════════
    public onRestartBtn() {

    if (this.audioSource && this.restartSound) {
        this.audioSource.playOneShot(this.restartSound);
    }

    this.cancelDrag();

    if (this.gameOverPanel)
        this.gameOverPanel.active = false;

    for (let r = 0; r < ROWS; r++)
        for (let c = 0; c < COLS; c++) {
            this.boardData[r][c] = -1;
            this.setCellColor(r, c, -1);
        }

    this.score = 0;
    this.updateScoreUI();
    this.dealPieces();
    }
}